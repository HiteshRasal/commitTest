//
//  ITCallVC.m
//  ITSDesignProject
//
//  Created by Jags on 10/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ITCallVC.h"

@interface ITCallVC ()

@end

@implementation ITCallVC

- (void)viewDidLoad {
    [super viewDidLoad];
   
 

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
