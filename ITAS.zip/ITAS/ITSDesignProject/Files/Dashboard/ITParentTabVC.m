//
//  ITParentTabVC.m
//  ITSDesignProject
//
//  Created by Jags on 10/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <PankanisAppKit/PankanisAppKit.h>

@interface ITParentTabVC ()

@end

@implementation ITParentTabVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    SWRevealViewController *revealController = [self revealViewController];
    [revealController panGestureRecognizer];
    [revealController tapGestureRecognizer];
    [_homeNavBar setButtonSideMenuClicked:^{
        [revealController revealToggle:self];
    }];
    
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(localize) name:MCLocalizationLanguageDidChangeNotification object:nil];
  
}
- (void)localize
{
    if ([self respondsToSelector:@selector(updateTabContent)]) {
        [self updateTabContent];
    }
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
  
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
