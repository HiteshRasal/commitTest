//
//  ITCallVC.h
//  ITSDesignProject
//
//  Created by Jags on 10/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ITParentTabVC.h"

@interface ITCallVC : ITParentTabVC

@end
