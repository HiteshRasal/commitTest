//
//  ITParentTabVC.h
//  ITSDesignProject
//
//  Created by Jags on 10/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeNavigationBar.h"
#import "MCLocalization.h"
@interface ITParentTabVC : UIViewController
@property (nonatomic,weak) IBOutlet HomeNavigationBar * homeNavBar;
- (void)updateTabContent;
@end
