//
//  ITHappinessVC.h
//  ITSDesignProject
//
//  Created by roshan on 11/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ITParentTabVC.h"
@interface ITHappinessVC : ITParentTabVC

@end
