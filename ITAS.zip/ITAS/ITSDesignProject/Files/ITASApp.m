//
//  ITASApplication.m
//  ITSDesignProject
//
//  Created by Jagprit Batra on 8/9/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ITASApp.h"

@implementation ITASApp

-(instancetype)init {
    self = [super init];
    if (self != nil) {
        
    }
    return self;
}

-(void)startup {
    
    [super startup];
   
  _tabBarHandler = [ITTabBarHandler sharedInstance];
  _tabBarHandler.tabVC = INSTANTIATE(@"TYTabBarController");
   
}


-(void)setImageIcon:(UIImage*)image WithText:(NSString*)strText andlabel:(UILabel *)lableForStr{
    
    NSTextAttachment *attachment = [[NSTextAttachment alloc] init];
    attachment.image = image;
    float offsetY = -1.5; //This can be dynamic with respect to size of image and UILabel
    attachment.bounds = CGRectIntegral( CGRectMake(-3, offsetY, 15, 11));
    NSMutableAttributedString *attachmentString = [[NSMutableAttributedString alloc] initWithAttributedString:[NSAttributedString attributedStringWithAttachment:attachment]];
    NSMutableAttributedString *myString= [[NSMutableAttributedString alloc] initWithString:strText];
    [attachmentString appendAttributedString:myString];
    lableForStr.attributedText = attachmentString;
}

- (CGFloat)getTextHeightFromString:(NSString *)text ViewWidth:(CGFloat)width WithPading:(CGFloat)pading AndFontSize:(CGFloat)fontSize
{
    NSDictionary *attributes = @{NSFontAttributeName: [UIFont systemFontOfSize:fontSize]};
    CGRect rect = [text boundingRectWithSize:CGSizeMake(width, MAXFLOAT)
                                     options:NSStringDrawingUsesLineFragmentOrigin
                                  attributes:attributes
                                     context:nil];
    return rect.size.width + pading;
}
-(void)setImageIcon:(UIImage*)image WithText:(NSString*)strText andlabel:(UILabel *)lableForStr  andFloatX:(float)offSetX andFloatY:(float )offSetY andWidth:(float)floatWidth andFloatHeight:(float)floatHeight {
    
    NSTextAttachment *attachment = [[NSTextAttachment alloc] init];
    attachment.image = image;
    float offsetY = offSetY; //This can be dynamic with respect to size of image and UILabel
    attachment.bounds = CGRectIntegral( CGRectMake(offSetX, offsetY, floatWidth, floatHeight));
    
    NSMutableAttributedString *attachmentString = [[NSMutableAttributedString alloc] initWithAttributedString:[NSAttributedString attributedStringWithAttachment:attachment]];
    NSMutableAttributedString *myString= [[NSMutableAttributedString alloc] initWithString:strText];
    
    [attachmentString appendAttributedString:myString];
    
    lableForStr.attributedText = attachmentString;
}
-(void)sendDeviceTokenToServer:(NSString *)deviceToken {
    
}

@end
