//
//  ITASApplication.h
//  ITSDesignProject
//
//  Created by Jagprit Batra on 8/9/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTabBarHandler.h"
@interface ITASApp : PKLiteApplication
#define INSTANTIATE(viewController) [[UIStoryboard storyboardWithName:@"Dashboard" bundle:nil] instantiateViewControllerWithIdentifier:viewController];
@property (strong, nonatomic)  ITTabBarHandler * tabBarHandler;
@end
