//
//  ITASApplication.h
//  ITSDesignProject
//
//  Created by Jagprit Batra on 8/9/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTabBarHandler.h"
#import <PankanisAppKit/PankanisAppKit.h>
#import "FTAGetProfileModel.h"
@interface ITASApp : PKLiteApplication <SWRevealViewControllerDelegate>

#define INSTANTIATE_DASHBOARD(viewController) [[UIStoryboard storyboardWithName:@"Dashboard" bundle:nil] instantiateViewControllerWithIdentifier:viewController];

#define INSTANTIATE(viewController) [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:viewController];

@property (strong, nonatomic)  ITTabBarHandler * tabBarHandler;
@property (strong, nonatomic) SWRevealViewController *revealViewController;
@property(strong,nonatomic) CarbonTabSwipeNavigation * carbonDiscoverTab;
@property (strong,nonatomic) FTAGetProfileModel *ftaGetProfileModelobj;

- (SWRevealViewController*)getSetSWRevealViewController;
@end
