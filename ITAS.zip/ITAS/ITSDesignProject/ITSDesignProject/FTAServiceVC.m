//
//  FTAServiceVC.m
//  ITSDesignProject
//
//  Created by roshan on 23/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "FTAServiceVC.h"

@interface FTAServiceVC ()

@end

@implementation FTAServiceVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.homeNavBar.lblTitle.text=@"FTA Services";
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    if(indexPath.row==0){
        cell.textLabel.text=@"Service 1";
    }
    else{
        cell.textLabel.text=@"Service 2";
    }
    
    return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}


@end
