//
//  FTASearchVC.m
//  FTA
//
//  Created by Hitesh Rasal on 27/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import "FTASearchVC.h"

@interface FTASearchVC ()

@end

@implementation FTASearchVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UISearchController *searchController = [[UISearchController alloc] initWithSearchResultsController:self];
    searchController.searchResultsUpdater = self;
    self.navigationItem.titleView = searchController.searchBar;
    searchController.searchBar.placeholder = @"Enter SR Number";
    self.definesPresentationContext = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
