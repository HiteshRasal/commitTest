//
//  FTALoginModel.h
//  FTA
//
//  Created by Hitesh Rasal on 27/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import <PankanisAppKit/PankanisAppKit.h>
@class MofAcc;
@interface FTALoginModel : PKDictionaryWrapper

@property (strong,nonatomic) NSString *IntegrationId;
@property (strong,nonatomic) PKDictionaryListWrapper *mofListWrapper;
@end


@interface MofAcc : PKDictionaryWrapper
@property (strong,nonatomic) NSString *Id;
@property (strong,nonatomic) NSString *AccNameArabic;
@property (strong,nonatomic) NSString *TRNo;
@property (strong,nonatomic) NSString *TaxIDNumber;
@end
