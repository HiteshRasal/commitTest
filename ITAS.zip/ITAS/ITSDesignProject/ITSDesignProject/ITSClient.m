//
//  ITSClient.m
//  ITSDesignProject
//
//  Created by roshan on 24/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ITSClient.h"

@implementation ITSClient


#pragma mark - PSRM Api Request

+(void)authenticateLogin:(NSMutableDictionary *)dictionary withHeaders:(NSDictionary *)headers completionHandler:(void(^)(id result,NSError *error))handler{
   
    
    
   // NSString *strUrl = [NSString stringWithFormat:@"%@login/app",ITSApplication.bundleConfig.envConfig.baseurlToHost];
   
    NSString *strUrl=@"http://192.168.2.97:8102/authentication/v1/login";//psrm api req
  
    NSData *postData = [NSJSONSerialization dataWithJSONObject:dictionary options:0 error:nil];
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:strUrl withBody:postData ofContentType:@"application/json"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    [request setHTTPMethod:@"POST"];
    NSLog(@"ITASApplication %@",((ITASApp *)PankanisLiteApplication.client));
    [ITSApplication.client jsonFromRequest:request inBackground:TRUE inTimeout:timeOut completionHandler:^(id resultJSON, NSHTTPURLResponse *response, NSError *error) {
        
        NSLog(@"Login error%@",error.localizedDescription);
        NSLog(@"response of Login %@",response);
        handler(resultJSON,error);
    }];

    
}
+(void)getAccountsReq:(NSMutableDictionary *)headerDict andInpParameter:(NSMutableDictionary *)inpParameter andCompletionHandler:(void (^)(id, NSError *))handler{
    NSString *strUrl=psrmGetAccountsUrl;//psrm api req
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:inpParameter options:0 error:nil];
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:strUrl withBody:postData ofContentType:@"application/json"];
    [request setAllHTTPHeaderFields:headerDict];
    [request setHTTPBody:postData];
    [request setHTTPMethod:@"GET"];
    NSLog(@"ITASApplication %@",((ITASApp *)PankanisLiteApplication.client));
    [ITSApplication.client jsonFromRequest:request inBackground:TRUE inTimeout:timeOut completionHandler:^(id resultJSON, NSHTTPURLResponse *response, NSError *error) {
        
        NSLog(@"Login error%@",error.localizedDescription);
        NSLog(@"response of Login %@",response);
        handler(resultJSON,error);
    }];
}
+(void)getAccountDetailsReq:(NSMutableDictionary *)headerDict andInpParameter:(NSString *)accId andCompletionHandler:(void (^)(id, NSError *))handler{
    //NSString *strUrl=[NSString stringWithFormat:@"%@%@",psrmGetAccountDetailsUrl,accId];//psrm api req
    NSString *strUrl=psrmGetAccountDetailsUrl;//psrm api req
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:strUrl];
    
    
    [request setAllHTTPHeaderFields:headerDict];
    [request setHTTPMethod:@"GET"];
    
    
    
    [ITSApplication.client jsonFromRequest:request inBackground:TRUE inTimeout:timeOut completionHandler:^(id resultJSON, NSHTTPURLResponse *response, NSError *error) {
        
        NSLog(@"profile error%@",error.localizedDescription);
        NSLog(@"response of get profile %@",response);
        handler(resultJSON,error);
    }];
    
    
}


+(void)getProfileReq:(NSMutableDictionary *)headerDict andCompletionHandler:(void (^)(id, NSError *))handler{
    NSString *strUrl=@"http://192.168.2.97:8102/authentication/v1";//psrm api req
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:strUrl];
    [request setAllHTTPHeaderFields:headerDict];
    [request setHTTPMethod:@"GET"];
    
    
    
    [ITSApplication.client jsonFromRequest:request inBackground:TRUE inTimeout:timeOut completionHandler:^(id resultJSON, NSHTTPURLResponse *response, NSError *error) {
        
        NSLog(@"profile error%@",error.localizedDescription);
        NSLog(@"response of get profile %@",response);
        handler(resultJSON,error);
    }];
}

+(void)GetForms:(NSMutableDictionary *)dictionary withFormHeaders:(NSDictionary *)Formheader  CompletionHandler:(void(^)(id result,NSError *error))handler{
    NSString *strUrl = @" http://192.168.2.97:8102/authentication/v1/Forms";
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:strUrl withJSON:dictionary];
    [request setAllHTTPHeaderFields:Formheader];
    
    
    [ITSApplication.client jsonFromRequest:request inBackground:TRUE inTimeout:timeOut completionHandler:^(id resultJSON, NSHTTPURLResponse *response, NSError *error) {
        
        NSLog(@"Login error%@",error.localizedDescription);
        NSLog(@"response of Login %@",response);
        handler(resultJSON,error);
    }];

}//






+(NSDictionary *)headers{
    
    NSDictionary *headers = @{ @"content-type": @"application/json"};
    return headers;
}


+(NSDictionary *)formHeaders{
    
    NSDictionary * formheaders= @{ @"content-type": @"application/json",
                                   @"authorization": @"Basic U0FMQURNSU46U0FMQURNSU5fMQ==",
                                 };
    return formheaders;
}



+(void)getFTASiebelService:(NSDictionary *)headers andContactid:(NSString *)Contactid completionHandler:(void(^)(id result,NSError *error))handler{
    
    NSString *strUrl=@"http://192.168.1.154:9001/siebel-rest/v1.0/service/FTA Contact/QueryByExample?PageSize=20&StartRowNum=2&ViewMode=All";
   
    NSData *postData = [NSJSONSerialization dataWithJSONObject:[self siebelServiceRequestwithContactid:Contactid] options:0 error:nil];
    
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:strUrl withBody:postData ofContentType:@"application/json"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPMethod:@"POST"];
    
    
    [ITSApplication.client jsonFromRequest:request inBackground:TRUE inTimeout:timeOut completionHandler:^(id resultJSON, NSHTTPURLResponse *response, NSError *error) {
        
        NSLog(@"Siebel service error%@",error.localizedDescription);
        NSLog(@"Response of Siebel service%@",response);
        handler(resultJSON,error);
    }];

    
}


+(void)getServiceRequestDetails:(NSDictionary *)headers andContactid:(NSString *)Contactid completionHandler:(void(^)(id result,NSError *error))handler{
    
    NSString *strUrl=@"http://192.168.1.154:9001/siebel-rest/v1.0/service/FTA Contact/QueryByExample?PageSize=20&StartRowNum=2&ViewMode=All";
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:[self siebelServiceRequestwithContactid:Contactid] options:0 error:nil];
    
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:strUrl withBody:postData ofContentType:@"application/json"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPMethod:@"POST"];
    
    
    [ITSApplication.client jsonFromRequest:request inBackground:TRUE inTimeout:timeOut completionHandler:^(id resultJSON, NSHTTPURLResponse *response, NSError *error) {
        
        NSLog(@"Siebel service error%@",error.localizedDescription);
        NSLog(@"Response of Siebel service%@",response);
        handler(resultJSON,error);
    }];
    
    
}

#pragma mark - Siebel Api request
+(void)getAccountUsingPSRMid:(NSString *)psrmId andPageSize:(NSString *)pageSize andStartRowNum:(NSString *)startRowNum andCompletionHandler:(void (^)(id, NSError *))handler{
    NSString *strUrl=@"http://192.168.1.154:9001/siebel-rest/v1.0/service/FTA ContactAccountBS/QueryPage"; //sibel request
    NSString *encodeUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    
    NSDictionary *parameters = @{
                                 @"body":@{
                                         @"ChildPagination":@"true",
                                         @"LOVLanguageMode":@"LIC",
                                         @"SiebelMessageIn":@{
                                                 @"MessageId":@"",
                                                 @"MessageType":@"Integration Object",
                                                 @"IntObjectName":@"Internal FTA Contact Account",
                                                 @"IntObjectFormat":@"Siebel Hierarchical",
                                                 @"ListOfInternal FTA Contact Account":@{
                                                         @"MoF Contact":@{@"Integration Id": @"='1-123923'",
                                                                          @"Id":@"",
                                                                          @"ListOfMoF Account":@{
                                                                                  @"pagesize": @"3",
                                                                                  @"startrownum": @"0",
                                                                                  @"recordcountneeded": @"true",
                                                                                  @"MoF Account":@{
                                                                                          @"Name Arabic":@"" ,
                                                                                          @"Name English":@"",
                                                                                          @"MoF Contact Relation Type":@"",
                                                                                          @"Id":@"",
                                                                                          @"TR No":@"",
                                                                                          @"Tax ID Number":@"",
                                                                                          @"WHK":@"",
                                                                                          @"TAAN":@""
                                                                                          }
                                                                                  }
                                                                          }
                                                         }
                                                 }
                                         
                                         }
                                 };
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:encodeUrl withJSON:parameters];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:[self headerDictForSibelApi]];
    [request setHTTPBody:postData];
    
    [ITSApplication.client jsonFromRequest:request inBackground:TRUE inTimeout:timeOut completionHandler:^(id resultJSON, NSHTTPURLResponse *response, NSError *error) {
        
        NSLog(@"Siebel service error%@",error.localizedDescription);
        NSLog(@"Response of getAccountUsingPSRMid%@",(NSDictionary *)resultJSON);
        handler(resultJSON,error);
    }];
}
+(void)getAccountUsingPSRMid:(NSString *)psrmId andCompletionHandler:(void (^)(id, NSError *))handler{
    ////psrmid = 5991814191
    NSString *strUrl=@"http://192.168.1.154:9001/siebel-rest/v1.0/service/FTA ContactAccountBS/QueryPage"; //sibel request
    NSString *encodeUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    
    NSDictionary *parameters = @{
                                 @"body":@{
                                         @"ChildPagination":@"true",
                                         @"LOVLanguageMode":@"LIC",
                                         @"SiebelMessageIn":@{
                                                 @"MessageId":@"",
                                                 @"MessageType":@"Integration Object",
                                                 @"IntObjectName":@"Internal FTA Contact Account",
                                                 @"IntObjectFormat":@"Siebel Hierarchical",
                                                 @"ListOfInternal FTA Contact Account":@{
                                                         @"MoF Contact":@{@"Integration Id": @"='1-123923'",
                                                                          @"Id":@"",
                                                                          @"ListOfMoF Account":@{
                                                                                  @"pagesize": @"3",
                                                                                  @"startrownum": @"0",
                                                                                  @"recordcountneeded": @"true",
                                                                                  @"MoF Account":@{
                                                                                          @"Name Arabic":@"" ,
                                                                                          @"Name English":@"",
                                                                                          @"MoF Contact Relation Type":@"",
                                                                                          @"Id":@"",
                                                                                          @"TR No":@"",
                                                                                          @"Tax ID Number":@"",
                                                                                          @"WHK":@"",
                                                                                          @"TAAN":@""
                                                                                          }
                                                                                  }
                                                                          }
                                                         }
                                                 }
                                         
                                         }
                                 };
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:encodeUrl withJSON:parameters];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:[self headerDictForSibelApi]];
    [request setHTTPBody:postData];
    
    [ITSApplication.client jsonFromRequest:request inBackground:TRUE inTimeout:timeOut completionHandler:^(id resultJSON, NSHTTPURLResponse *response, NSError *error) {
        
        NSLog(@"Siebel service error%@",error.localizedDescription);
        NSLog(@"Response of getAccountUsingPSRMid%@",(NSDictionary *)resultJSON);
        handler(resultJSON,error);
    }];
}

+(void)getListOfSrReq:(NSString *)integrationId andCompletionHandler:(void (^)(id, NSError *))handler{
    NSString *strUrl=@"http://192.168.1.154:9001/siebel-rest/v1.0/service/FTA Contact/QueryPage"; //sibel request
    NSString *encodeUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSDictionary *parameters = @{
        @"body":@{
            @"ChildPagination":@"true",
            @"LOVLanguageMode":@"LIC",
            @"SiebelMessageIn":@{
                @"MessageId":@"",
                @"MessageType":@"Integration Object",
                @"IntObjectName":@"Internal FTA ContactREST",
                @"IntObjectFormat":@"Siebel Hierarchical",
                @"ListOfInternal FTA ContactREST": @{
                    @"MoF Contact": @{
                        @"Integration Id": @"='1-45456'",
                        @"Id":@"",
                        @"ListOfService Request":@{
                            @"pagesize": @"3",
                            @"startrownum": @"0",
                            @"recordcountneeded": @"true",
                            @"Service Request":@{
                                @"SR Type":@"" ,
                                @"Sub Type":@"",
                                @"SR Number":@"",
                                @"Created":@"",
                                @"Description":@"",
                                @"Id":@"",
                                @"Account":@"",
                                @"TR No":@"",
                                @"Status":@"",
                                @"Resolution Code":@"",
                                @"Sub-Status":@"",
                                @"MoF Email Subject":@""
                            }
                        }
                    }
                }              
            }
            
        }
        };
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:encodeUrl withJSON:parameters];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:[self headerDictForSibelApi]];
    [request setHTTPBody:postData];
    
    [ITSApplication.client jsonFromRequest:request inBackground:TRUE inTimeout:timeOut completionHandler:^(id resultJSON, NSHTTPURLResponse *response, NSError *error) {
        
        NSLog(@"Siebel service error%@",error.localizedDescription);
        NSLog(@"Response of getListOfSrReq%@",(NSDictionary *)resultJSON);
        handler(resultJSON,error);
    }];

}




+(void)fetchSrLinkedAcc:(NSString *)srType andAccId:(NSString *)accId completionHandler:(void (^)(id result, NSError *error))handler{
    //Query List of SR linked to Account http://192.168.1.154:9001/siebel-rest/v1.0/service/FTA Service Request/QueryPage?
    
    NSString *strUrl=@"http://192.168.1.154:9001/siebel-rest/v1.0/service/FTA Service Request/QueryPage"; //sibel request
    NSString *encodeUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    
    NSDictionary *parameters =@{
                                @"body":@{
                                        @"ChildPagination":@"true",
                                        @"LOVLanguageMode":@"LIC",
                                        @"SiebelMessageIn":@{
                                                @"MessageId":@"",
                                                @"MessageType":@"Integration Object",
                                                @"IntObjectName":@"Service Request",
                                                @"IntObjectFormat":@"Siebel Hierarchical",
                                                @"ListOfService Request":@{
                                                        @"pagesize": @"3",
                                                        @"startrownum": @"0",
                                                        @"recordcountneeded": @"true",
                                                        @"Service Request":@{@"Account Id": @"='1-9F9N'",
                                                                             @"Id":@"",
                                                                             @"SR Type":@"" ,
                                                                             @"Sub Type":@"",
                                                                             @"SR Number":@"",
                                                                             @"Created":@"",
                                                                             @"Description":@"",
                                                                             @"Account":@"",
                                                                             @"TR No":@"",
                                                                             @"Status":@"",
                                                                             @"Resolution Code":@"",
                                                                             @"Sub-Status":@"",
                                                                             @"MoF Email Subject":@""
                                                                             }
                                                        }
                                                }              
                                        }
                                };
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:encodeUrl withJSON:parameters];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:[self headerDictForSibelApi]];
    [request setHTTPBody:postData];
    [ITSApplication.client jsonFromRequest:request inBackground:TRUE inTimeout:timeOut completionHandler:^(id resultJSON, NSHTTPURLResponse *response, NSError *error) {
        
        NSLog(@"Siebel service error%@",error.localizedDescription);
        NSLog(@"Response of Sr linked to account %@",(NSDictionary *)resultJSON);
        handler(resultJSON,error);
    }];

}


+(void)fetchListingForType:(NSString *)srType andContactid:(NSString *)contactId completionHandler:(void(^)(id result,NSError *error))handler{
    
    
    NSDictionary *headers = @{ @"content-type": @"application/json",
                               @"authorization": @"Basic U0FMQURNSU46U0FMQURNSU5fMQ==",
                               @"cache-control": @"no-cache",
                               @"postman-token": @"8458b59c-a570-9021-b8e1-562d6c4e4310" };
    NSDictionary *parameters = @{ @"body": @{ @"ChildPagination": @"true", @"LOVLanguageMode": @"LIC", @"SiebelMessageIn": @{ @"MessageId": @"", @"MessageType": @"Integration Object", @"IntObjectName": @"Internal FTA ContactREST", @"IntObjectFormat": @"Siebel Hierarchical", @"ListOfInternal FTA ContactREST": @{ @"MoF Contact": @{ @"Integration Id": @"='1-45456'", @"Id": @"", @"ListOfService Request": @{ @"pagesize": @"3", @"startrownum": @"0", @"recordcountneeded": @"true", @"Service Request": @{ @"SR Type": @"", @"Sub Type": @"", @"SR Number": @"", @"Created": @"", @"Description": @"", @"Id": @"", @"Account": @"", @"TR No": @"", @"Status": @"", @"Resolution Code": @"", @"Sub-Status": @"", @"MoF Email Subject": @"" } } } } } } };
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    NSString *url = @"http://192.168.1.154:9001/siebel-rest/v1.0/service/FTA Contact/QueryPage";
    NSString *encodeUrl =[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *request = [PKHTTPClient requestForURL:encodeUrl withJSON:parameters];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:headers];
   // [request setHTTPBody:postData];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                                                        NSLog(@"%@", httpResponse);
                                                        
                                                        id json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                        
                                                        NSLog(@" SAVING json : %@", json);
                                                        handler(json,error);
                                                    }
                                                }];
    [dataTask resume];
    
}



+(NSDictionary *)siebelServiceRequestwithContactid:(id)contactid{
   
    NSString *Contactid=contactid;
    
    NSDictionary *parameters = @{ @"body": @{ @"SiebelMessage": @{ @"MessageId": @"", @"MessageType": @"Integration Object", @"IntObjectName": @"FTA Contact", @"IntObjectFormat": @"Siebel Hierarchical", @"ListOfFTA Contact": @{ @"MoF Contact": @{ @"Integration Id":Contactid, @"ListOfService Request": @{ @"Service Request": @{ @"Service Request Number": @"", @"SR Type": @"Complaints" } } } } } } };
    return parameters;
    
}
#pragma mark - headers for login api or PSRM

+(NSMutableDictionary *)headerDictForPSRMApi{
    NSMutableDictionary *headers =[[NSMutableDictionary alloc] init];
    [headers setValue:@"application/json" forKey:@"content-type"];
    //[headers setValue:@"no-cache" forKey:@"cache-control"];
    //[headers setValue:@"3d7243b4-1c45-fabf-1005-4b34c93b63aa" forKey:@"postman-token"];
    return headers;
}


+(NSDictionary *)addHeaders:(NSString *)accesstoken{
    
    NSString * accessstoken= [NSString stringWithFormat:@"Bearer %@",accesstoken];
    
    NSDictionary * profileheaders= @{ @"content-type": @"application/json",
                                      @"authorization":accessstoken };
    
    
    return profileheaders;
    
}

#pragma mark - headers for Sibel Api
+(NSMutableDictionary *)headerDictForSibelApi{
    NSMutableDictionary *headers =[[NSMutableDictionary alloc] init];
    [headers setValue:@"application/json" forKey:@"content-type"];
    [headers setValue:@"Basic U0FMQURNSU46U0FMQURNSU5fMQ==" forKey:@"authorization"];
    
    return headers;
}

@end
