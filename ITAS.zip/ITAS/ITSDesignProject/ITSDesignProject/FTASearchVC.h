//
//  FTASearchVC.h
//  FTA
//
//  Created by Hitesh Rasal on 27/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FTASearchVC : UIViewController

@end
