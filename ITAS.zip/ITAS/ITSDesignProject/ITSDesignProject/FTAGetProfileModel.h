//
//  FTAGetProfileModel.h
//  FTA
//
//  Created by Hitesh Rasal on 27/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import <PankanisAppKit/PankanisAppKit.h>

@class AccountsByPsrmIdModel,AccountsListModel,AccountsDetailApiModel,AccountDetailTaxTypeModel;

@interface FTAGetProfileModel : PKDictionaryWrapper
@property (strong,nonatomic) NSString *email;
@property (strong,nonatomic) NSString *mobilePhoneCountryCode;
@property (strong,nonatomic) NSString *mobilePhoneNumber;
@property (strong,nonatomic) NSString *name;
@property (strong,nonatomic) NSString *officePhoneCountryCode;
@property (strong,nonatomic) NSString *officePhoneNumber;
@property (strong,nonatomic) NSString *psrmContactId;
@end


@interface AccountsByPsrmIdModel : PKDictionaryWrapper
@property (strong,nonatomic) PKDictionaryListWrapper *accountsListWrapper;
@end


@interface AccountsListModel : PKDictionaryWrapper

@property (strong,nonatomic) NSString *accountId;
@property (strong,nonatomic) NSString *accountName;
@property (strong,nonatomic) NSString *accountType;
@property (strong,nonatomic) NSString *relationshipType;
@property (strong,nonatomic) NSString *relationshipStartDate;
@end



@interface AccountsDetailApiModel : PKDictionaryWrapper

@property (strong,nonatomic) NSString *nameArabic;
@property (strong,nonatomic) NSString *nameEnglish;
@property (strong,nonatomic) NSString *contactNameEnglish;
@property (strong,nonatomic) NSString *addressLine1;
@property (strong,nonatomic) NSString *addressLine2;
@property (strong,nonatomic) NSString *addressLine3;
@property (strong,nonatomic) NSString *addressLine4;
@property (strong,nonatomic) NSString *country;
@property (strong,nonatomic) NSString *state;
@property (strong,nonatomic) NSString *postalCodeZip;
@property (strong,nonatomic) NSString *city;
@property (strong,nonatomic) NSString *phoneNumber;
@property (strong,nonatomic) NSString *mobileNumber;
@property (strong,nonatomic) NSString *emailAddress;
@property (strong,nonatomic) NSString *contactNameArabic;
@property (strong,nonatomic) PKDictionaryListWrapper *AccountDetailTaxTypeListWrapper;

@end

@interface AccountDetailTaxTypeModel : PKDictionaryWrapper

@property (strong,nonatomic) NSString *trn;
@property (strong,nonatomic) NSString *taan;
@property (strong,nonatomic) NSString *taxAgentName;
@property (strong,nonatomic) NSString *registrationDate;
@property (strong,nonatomic) NSString *nextFilingDate;
@property (strong,nonatomic) NSString *taxType;


@end
