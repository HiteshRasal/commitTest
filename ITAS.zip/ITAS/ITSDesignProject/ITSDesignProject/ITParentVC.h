//
//  ITParentVC.h
//  ITSDesignProject
//
//  Created by roshan on 11/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ITParentVC : UIViewController
- (void)updateContent;
@end
