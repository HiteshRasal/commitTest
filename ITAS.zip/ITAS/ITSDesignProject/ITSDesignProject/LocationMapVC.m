//
//  LocationMapVC.m
//  ITSDesignProject
//
//  Created by roshan on 22/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "LocationMapVC.h"
#import "MapAnnotation.h"
@interface LocationMapVC ()<MKMapViewDelegate,MKAnnotation>
{
    MKPointAnnotation *myAnnotation;
    CLLocationCoordinate2D cord;
    UIBarButtonItem * leftBarbutton;
}
@end

@implementation LocationMapVC
@synthesize mapView = mapView;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationController.navigationBar setHidden:NO];
    
    leftBarbutton =[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Back", @"") style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
    self.navigationItem.leftBarButtonItem=leftBarbutton;

    
    self.mapView.delegate=self;
    mapView.centerCoordinate = CLLocationCoordinate2DMake(19.114979,72.849891);
    mapView.mapType = MKMapTypeStandard;
    CLLocationCoordinate2D location;
    location.latitude = _lattitude;
    location.longitude = _longitude;
    MapAnnotation *newAnnotation = [[MapAnnotation alloc]
                                    initWithTitle:_Pintitle andCoordinate:location];
    [mapView addAnnotation:newAnnotation];
    mapView.delegate = self;
    
}
- (IBAction)Back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)backAction{
     [self.navigationController popViewControllerAnimated:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
    
    if ([annotation isKindOfClass:[MKPointAnnotation class]])
    {
        MKAnnotationView *pinView = (MKAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:@"CustomPinAnnotationView"];
        if (!pinView)
        {
            pinView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"CustomPinAnnotationView"];
            pinView.canShowCallout = YES;
            pinView.calloutOffset = CGPointMake(0, 32);

          
        } else {
            pinView.annotation = annotation;
        }
        return pinView;
    }
    return nil;
}

-(void)zoomInOnLocation:(CLLocationCoordinate2D)location
{
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(location, 200, 200);
    [self.mapView setRegion:[self.mapView regionThatFits:region] animated:YES];
}
-(void)mapView:(MKMapView *)mv didAddAnnotationViews:(NSArray *)views
{
    MKAnnotationView *annotationView = [views objectAtIndex:0];
    id <MKAnnotation> mp = [annotationView annotation];
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance
    ([mp coordinate], 5000, 5000);
    [mv setRegion:region animated:YES];
    [mv selectAnnotation:mp animated:YES];
}


@end
