//
//  SibelApiReqModel.h
//  FTA
//
//  Created by Hitesh Rasal on 28/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import <PankanisAppKit/PankanisAppKit.h>
@class MofAccForPSRM;
@class SrLinkAccountToPsrmModel,ServiceRequestListModel;
@interface SibelApiReqModel : PKDictionaryWrapper

@end


@interface getAcctByPSRMIdApiModel : PKDictionaryWrapper
@property (strong,nonatomic) NSString *IntegrationId;
@property (strong,nonatomic) PKDictionaryListWrapper *mofListWrapper;

@end

@interface MofAccForPSRM : PKDictionaryWrapper
@property (strong,nonatomic) NSString *Id;
@property (strong,nonatomic) NSString *AccNameArabic;
@property (strong,nonatomic) NSString *TRNo;
@property (strong,nonatomic) NSString *TaxIDNumber;
@end




@interface SrLinkAccountToPsrmModel : PKDictionaryWrapper
@property (strong,nonatomic) PKDictionaryListWrapper *serviceRequestListWrapper;
@end

@interface ServiceRequestListModel : PKDictionaryWrapper
@property (strong,nonatomic) NSString *Account;
@property (strong,nonatomic) NSString *AccountId;
@property (strong,nonatomic) NSString *CreatedDate;
@property (strong,nonatomic) NSString *Description;
@property (strong,nonatomic) NSString *mofEmailSubject;
@property (strong,nonatomic) NSString *srNumber;
@property (strong,nonatomic) NSString *srType;
@property (strong,nonatomic) NSString *status;
@property (strong,nonatomic) NSString *subStatus;
@property (strong,nonatomic) NSString *trNo;
@end
