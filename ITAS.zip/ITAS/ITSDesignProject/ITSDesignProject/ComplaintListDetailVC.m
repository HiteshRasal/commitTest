//
//  ComplaintListDetailVC.m
//  ITSDesignProject
//
//  Created by roshan on 16/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ComplaintListDetailVC.h"
#import "ComplaintListDetailCell.h"
#import "ServiceReqDetailsVC.h"
#import "SibelApiReqModel.h"

@interface ComplaintListDetailVC ()
{
    BOOL isFilter;
    NSMutableArray *listArray;
    NSMutableArray * searcharray;
    NSMutableArray *serviceReqArray;

}
@end

@implementation ComplaintListDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UINib *nib = [UINib nibWithNibName:NSStringFromClass([ComplaintListDetailCell class]) bundle:[NSBundle mainBundle]];
    [self.tableView registerNib:nib forCellReuseIdentifier:NSStringFromClass([ComplaintListDetailCell class])];
    listArray=[[NSMutableArray alloc]initWithObjects:@"Emirates Airlinesdfdfdfdfdfdfdfdfdfdfdf",@"Air India",@"Jet",nil];
    serviceReqArray = [[NSMutableArray  alloc] init];
    _tableView.estimatedRowHeight=94.0f;
    
    
    [ITSClient getFTASiebelService:[ITSClient headers] andContactid:@"1-45456" completionHandler:^(id result, NSError *error) {
        NSLog(@"SiebelService response");
        
    }];
    [self srLinkedAccApiReq:_srTypeVal andAcctId:_accId];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ComplaintListDetailCell   *cell  = (ComplaintListDetailCell *)[self.tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ComplaintListDetailCell class])];
   
    //cell.lblTitle.text= [listArray objectAtIndex:indexPath.row];
    cell.lblSRNO.text=[(NSDictionary *)[serviceReqArray objectAtIndex:indexPath.row] valueForKey:@"Account Id"];
    cell.lblCreatedDate.text=[(NSDictionary *)[serviceReqArray objectAtIndex:indexPath.row] valueForKey:@"Created"];
    
    cell.lblTitle.textAlignment = NSTextAlignmentRight;
    
    return cell;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
   /* if(isFilter){
    return _filteredTableData.count;
  }
    else
   return listArray.count;*/
    return [serviceReqArray count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension ;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    ServiceReqDetailsVC * servcdet=INSTANTIATE(@"ServiceReqDetailsVC");
    [self.navigationController pushViewController:servcdet animated:YES];
}

/*
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if(searchText.length == 0)
    {
        [_filteredTableData removeAllObjects];
        [_filteredTableData addObjectsFromArray:listArray];
    }
    else
    {
        [_filteredTableData removeAllObjects];
        
        for (NSString* string in listArray)
        {
            NSRange nameRange = [string rangeOfString:searchText options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch)];
            if(nameRange.location != NSNotFound)
            {
                [_filteredTableData addObject:string];
            }
        }
    }
    [_tableView reloadData];
}
*/

- (void)updateContent
{
    [self.tableView reloadData];
}

-(void)srLinkedAccApiReq:(NSString *)srType andAcctId:(NSString *)accId{
    [DejalBezelActivityView activityViewForView:self.view withLabel:@"Loading" width:100];
    NSString *formattedAccId =[NSString stringWithFormat:@"='%@'",accId];
    NSString *formattedsrType =[NSString stringWithFormat:@"='%@'",srType];
    [ITSClient fetchSrLinkedAcc:formattedsrType andAccId:formattedAccId completionHandler:^(id result, NSError *error) {
        if (error) {
            [DejalKeyboardActivityView removeViewAnimated:YES];
            DDLogInfo(@" error %@",error.localizedDescription);
        }else{
            [iOSHelper performActionOnMainThread:^{
                NSDictionary *respDict =(NSDictionary *)result;
                SrLinkAccountToPsrmModel *srLinkAccountToPsrmModelObj = [[SrLinkAccountToPsrmModel alloc] initWithDictionary:[respDict valueForKey:@"SiebelMessageOut"]];
                [serviceReqArray addObjectsFromArray:srLinkAccountToPsrmModelObj.serviceRequestListWrapper.items];
                DLog(@" serviceReqArray %@",serviceReqArray);
                [DejalKeyboardActivityView removeViewAnimated:YES];
                [_tableView reloadData];
            }];
            
           // serviceReqArray = [respDict valueForKeyPath:@"SiebelMessageOut.Service Request"];
        }
    }];
    
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:YES];
    [DejalKeyboardActivityView removeViewAnimated:YES];
}
@end
