//
//  GenericMethods.m
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 19/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "GenericMethods.h"
#import "AppDelegate.h"
#import "LanguageManager.h"

@implementation GenericMethods
+(void)alertWithOneBtn:(NSString *)title andMsg:(NSString *)message andFirstBtnTitle:(NSString *)firstBtnTitle  andViewController:(UIViewController *)currentVc andCompletionHandler:(void (^)(BOOL result))completionHandler{
    UIAlertController * alert=[UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction
                         actionWithTitle:firstBtnTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                             if (completionHandler != nil) {
                                 BOOL result = YES;
                                 [currentVc dismissViewControllerAnimated:YES completion:nil];
                                 completionHandler(result);
                             }
                             [currentVc dismissViewControllerAnimated:YES completion:nil];
                         }];
    [alert addAction:ok];
    [currentVc presentViewController:alert animated:YES completion:nil];
}
+(BOOL)checkDocDirPath:(NSString *)name{
    NSString* documentsPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    
    NSString* foofile = [documentsPath stringByAppendingPathComponent:name];
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:foofile];
    return fileExists;
}
+(NSData *)fetchDataFromDocDir:(NSString *)pathComponent{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *savedJSonPath = [documentsDirectory stringByAppendingPathComponent:pathComponent];
    NSData * data = [NSData dataWithContentsOfFile:savedJSonPath];
    return data;
}
+(NSString *)docDirFilePath:(NSString *)strForPathComponet{
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirectory = [path objectAtIndex:0];
    NSString *filePath =[documentDirectory stringByAppendingPathComponent:strForPathComponet];
    return filePath;
}
+(void)reloadRootViewController
{
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    NSString *storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle:nil];
    delegate.window.rootViewController = [storyboard instantiateInitialViewController];
    
}
+(void)storeLangAndLangCode:(int)intForLangCode andkeyForInt:(NSString *)keyForInt andStoreLangVal:(NSString *)langVal andstoreLangKey:(NSString *)langKey{
    [LanguageManager saveLanguageByIndex:intForLangCode];
    [[NSUserDefaults standardUserDefaults] setInteger:intForLangCode forKey:keyForInt];
    [[NSUserDefaults standardUserDefaults] setValue:langVal forKey:langKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
@end
