//
//  SplashScreenVC.h
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 20/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSString *gblLoginOrNot;

@interface SplashScreenVC : UIViewController

@end
