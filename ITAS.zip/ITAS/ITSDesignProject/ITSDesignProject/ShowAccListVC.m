//
//  ShowAccListVC.m
//  FTA
//
//  Created by Hitesh Rasal on 27/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import "ShowAccListVC.h"
#import "psrmAcctListCell.h"
#import "ComplaintListVC.h"
#import "ExpandableTableView.h"
#import "FTAShowAccHeader.h"
#import "SibelApiReqModel.h"
static NSString *const kTableViewCellReuseIdentifier = @"TableViewCellReuseIdentifier";

@interface ShowAccListVC ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>{
    //FTAShowAccListHeaderCell *headerView;
    FTAShowAccHeader *headerView;
    NSMutableArray *accListTestArray;//test
    NSMutableArray *displayArray;//test
    
    BOOL paginatorFlag;
    BOOL reloadPage;
    BOOL stopLoadMore;
    
    
}
@property (strong, nonatomic) IBOutlet ExpandableTableView *tableView;

@end

@implementation ShowAccListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Back", @"") style:UIBarButtonItemStylePlain target:self action:@selector(dismissVC)];
    NSLog(@"account list %@",self.accListArray);//for use
    
    /* //for testing json data
    accListTestArray =[[NSMutableArray alloc] init];
    NSString *filePath =[[NSBundle mainBundle] pathForResource:@"Account list" ofType:@"json"];
    NSData *data  =[NSData dataWithContentsOfFile:filePath];
    NSDictionary *dataDict =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    accListTestArray =[dataDict valueForKeyPath:@"SiebelMessageOut.MoF Contact.MoF Account"];
    
    displayArray =[[NSMutableArray alloc] init];
    for (int i =0; i < 10; i++) {
        [displayArray addObject:[accListTestArray objectAtIndex:i]];
    }
    NSLog(@"disPlay array count %lu",(unsigned long)displayArray.count);
    */
    UINib *psrmAcctListCellnib =[UINib nibWithNibName:@"psrmAcctListCell" bundle:nil];
    [_tableView registerNib:psrmAcctListCellnib forCellReuseIdentifier:@"psrmAcctListCellIdef"];
    _tableView.allowMultipleSectionsOpen = YES;

    [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:kTableViewCellReuseIdentifier];
    [_tableView registerNib:[UINib nibWithNibName:@"FTAShowAccHeader" bundle:nil] forHeaderFooterViewReuseIdentifier:kAccordionHeaderViewReuseIdentifier];
    [_tableView reloadData];
}
-(void)dismissVC{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        
    }else if (indexPath.section == 1){
        
        ComplaintListVC  *complaintsVC=INSTANTIATE(@"ComplaintListVC");
        complaintsVC.TabName=@"Complaints";
        complaintsVC.gblAccId = [(NSDictionary *)[_accListArray objectAtIndex:indexPath.row] valueForKey:@"Id"];
        
        [self.navigationController pushViewController:complaintsVC animated:YES];
    }
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section == 0) {
        return [_accListArray count];
    }else if (section == 1){
        return [_accListArray count];
         //return [displayArray count];//for test
    }
    return 0;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return kDefaultAccordionHeaderViewHeight;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *identifier = @"psrmAcctListCellIdef";
    psrmAcctListCell *cell =[tableView dequeueReusableCellWithIdentifier:identifier];
    if (indexPath.section == 0) {
        cell.lblAcct.text = [(NSDictionary *)[_accListArray objectAtIndex:indexPath.row] valueForKey:@"Name Arabic"];
    }else if (indexPath.section == 1){
        cell.lblAcct.text = [(NSDictionary *)[_accListArray objectAtIndex:indexPath.row] valueForKey:@"Name Arabic"];
        //cell.lblAcct.text = [(NSDictionary *)[displayArray objectAtIndex:indexPath.row] valueForKey:@"Name Arabic"];//for test
    }
    
    
    return cell;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:kAccordionHeaderViewReuseIdentifier];
    if (section == 0) {
        headerView.lblHeaderName.text = @"Create By Me";
    }else if (section == 1){
        headerView.lblHeaderName.text = @"Select a Profile";
    }
    
    ExpandableTableView * tblView = (ExpandableTableView*)tableView;
    if ([tblView isSectionOpen:section])
        headerView.headerImg.image =[UIImage imageNamed:@"Up.png"];
    else
        headerView.headerImg.image =[UIImage imageNamed:@"down.png"];
    return headerView;
}
/* //for paging
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGPoint offset = scrollView.contentOffset;
    CGRect bounds = scrollView.bounds;
    CGSize size = scrollView.contentSize;
    UIEdgeInsets inset = scrollView.contentInset;
    float y = offset.y + bounds.size.height - inset.bottom;
    float h = size.height;
    
    float reload_distance = 15;
    if (!stopLoadMore) {
        if(y > h + reload_distance)
        {
            
            if (!reloadPage) {
                [self getAccUsingPSRMId:@"pass psrm id"];
                
                NSLog(@"disPlay array count %lu",(unsigned long)displayArray.count);
            }
        }
    }
    
    
}*/

#pragma mark - ExpandableTableViewDelegate

- (void)tableView:(ExpandableTableView *)tableView willOpenSection:(NSInteger)section withHeader:(UITableViewHeaderFooterView *)header {
    
    
}

- (void)tableView:(ExpandableTableView *)tableView didOpenSection:(NSInteger)section withHeader:(UITableViewHeaderFooterView *)header {
    
}

- (void)tableView:(ExpandableTableView *)tableView willCloseSection:(NSInteger)section withHeader:(UITableViewHeaderFooterView *)header {
    
    
    
}

- (void)tableView:(ExpandableTableView *)tableView didCloseSection:(NSInteger)section withHeader:(UITableViewHeaderFooterView *)header {
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - Api Request
-(void)getAccUsingPSRMId:(NSString *)pageSize{
    reloadPage = YES;
    NSString *startRowId =[NSString stringWithFormat:@"%d",(int)[_accListArray count]];
    
    [ITSClient getAccountUsingPSRMid:@"pass Psrm id" andPageSize:@"10" andStartRowNum:startRowId andCompletionHandler:^(id result, NSError *error) {
        if (error) {
            reloadPage = NO;
        }else{
            DLog(@"responce is %@",(NSDictionary *)result);
            NSDictionary *respDict = (NSDictionary *)result;
            getAcctByPSRMIdApiModel *getAcctByPSRMIdApiModelObj =[[getAcctByPSRMIdApiModel alloc] initWithDictionary:[respDict valueForKeyPath:@"SiebelMessageOut.MoF Contact"]];
            if (getAcctByPSRMIdApiModelObj == nil) {
                stopLoadMore = YES;
                reloadPage = NO;
            }else{
                [_accListArray addObjectsFromArray:getAcctByPSRMIdApiModelObj.mofListWrapper.items];
                stopLoadMore = NO;
                reloadPage = NO;
                [_tableView reloadData];
            }
            
            
        }
    }];
}
@end
