//
//  DashboardVC.m
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 14/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "DashboardVC.h"
#import "DashboradCollection.h"
#import "HeaderViewDashboard.h"
#import "ServiceRequestVC.h"
#import "FormsVC.h"
#import "ProfileVC.h"
#import "SettingsVC.h"
#import "LanguageManager.h"
#import "FeedbackVC.h"
#import "SplashScreenVC.h"
#import "ComplaintsVC.h"
#import "HomeNavigationBar.h"
#import "ComplaintListVC.h"
#import "ComplaintListDetailVC.h"
#import "FTAServiceVC.h"
#import "FAQVC.h"
#import "ShowAccListVC.h"
#import "SibelApiReqModel.h"
#import "ProfileInfoVC.h"

@interface DashboardVC (){
    UIPickerView *mofAccPicker;
    UIToolbar *toolBarAcc;
    NSMutableArray *accArray;
    NSMutableArray *accForPsrmIdArray;
    NSMutableArray *accForListSrArray;
}

@end

@implementation DashboardVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
     self.homeNavBar.lblTitle.text=@"Home";
    accArray =[NSMutableArray arrayWithObjects:@"Select",@"test",@"test2", nil];
    accForPsrmIdArray =[[NSMutableArray alloc] init];
    accForListSrArray =[[NSMutableArray alloc] init];
    [MCLocalization sharedInstance].language = @"en";
    [self.view setUserInteractionEnabled:NO];
    [self getAcctByPSRMIdApi:@"pass psrm Id"];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    
    NSInteger langCode = [[[NSUserDefaults standardUserDefaults] valueForKey:@"LangCode"] integerValue];
    [LanguageManager saveLanguageByIndex:langCode];
    self.title = NSLocalizedString(@"Home", @"");
    self.navigationItem.title=@"Home";
    
    
    UIBarButtonItem *leftBtn = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Logout", @"")  style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
    
    [self.navigationItem setLeftBarButtonItem:leftBtn];
    _collectionViewDasboard.delegate = self;
    _collectionViewDasboard.dataSource = self;
    [_collectionViewDasboard reloadData];
    
   // [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(localize) name:MCLocalizationLanguageDidChangeNotification object:nil];
    
    [self updateTabContent];

}

-(void)backAction{
    gblLoginOrNot = @"logOut";
    [self.navigationController popViewControllerAnimated:YES];
    
}
-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    

}
#pragma mark - CollectionView Delegate methods
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 7;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    UICollectionViewFlowLayout *flowLayout = (UICollectionViewFlowLayout*) collectionView.collectionViewLayout;
      float cellWidth = (CGRectGetWidth(collectionView.frame) - (flowLayout.sectionInset.left + flowLayout.sectionInset.right)-
        flowLayout.minimumInteritemSpacing) / 2;
        return CGSizeMake(cellWidth, cellWidth);
        
   
}


-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
   DashboradCollection *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"DashboradCollectionIdef" forIndexPath:indexPath];
 
    cell.lblBtnTitle.tag = indexPath.row;
    cell.btnImg.tag = indexPath.row;
    [self setTitleForBtn:cell];
    [self setImgBtn:cell];
    
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *reusableview = nil;
    
    if (kind == UICollectionElementKindSectionHeader) {
        HeaderViewDashboard *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HeaderView" forIndexPath:indexPath];
        
        reusableview = headerView;
    }
    return reusableview;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
   
    switch (indexPath.row) {
         
    case 0:
        {   /*
            ProfileInfoVC *profileInfoVcObj = INSTANTIATE(@"ProfileInfoVC");
            [self.navigationController pushViewController:profileInfoVcObj animated:YES];*/
            
            if (accForPsrmIdArray.count > 0) {
                ShowAccListVC *showListVc =[[ShowAccListVC alloc] initWithNibName:@"ShowAccListVC" bundle:nil];
                
                showListVc.accListArray = accForPsrmIdArray;
                showListVc.title = @"Account Listing";
                [self.navigationController pushViewController:showListVc animated:YES];
                //[self pickerViewForAcc];
            }else{
                [self listOfServiceReq:@"pass integration id"];
            }
            
            /*
            ComplaintListVC  *complaintsVC=INSTANTIATE(@"ComplaintListVC");
            complaintsVC.TabName=@"Suggestions";
            
          //   UINavigationController * navc=[[UINavigationController alloc]initWithRootViewController:complaintsVC];
            [self.navigationController pushViewController:complaintsVC animated:YES];*/
        }
        break;
        case 1:
        {
        
            ComplaintsVC  *complaintsVC=INSTANTIATE(@"ComplaintsVC");
            complaintsVC.TabName=@"Complaints";
        
            
            [self.navigationController pushViewController:complaintsVC animated:YES];
            
            
            //   FormsVC   *formsVC    = INSTANTIATE(@"FormsVC");// [self.storyboard instantiateViewControllerWithIdentifier:@"FormsVC"];
           // [self.navigationController pushViewController:formsVC animated:YES];
        }
            break;
        case 2:
        {
            ComplaintsVC  *complaintsVC=INSTANTIATE(@"ComplaintsVC");
            complaintsVC.TabName=@"Suggestions";

            [self.navigationController pushViewController:complaintsVC animated:YES];
            
           /* ProfileVC   *profileVC  = INSTANTIATE(@"ProfileVC");//[self.storyboard instantiateViewControllerWithIdentifier:@"ProfileVC"];
            [self.navigationController pushViewController:profileVC animated:YES];*/
            
        }
            break;
        case 3:
        {
            ComplaintsVC  *complaintsVC=INSTANTIATE(@"ComplaintsVC");
            complaintsVC.TabName=@"Enquiry";

            [self.navigationController pushViewController:complaintsVC animated:YES];
           
            
        }
            break;
        case 4:
        {
            FTAServiceVC * ftaservice= INSTANTIATE(@"FTAServiceVC");
            
            [self.navigationController pushViewController:ftaservice animated:YES];
        }
            break;
        case 5:
        {
           
        
        }
            break;
        case 6:
        {
            FAQVC * faq=INSTANTIATE(@"FAQVC")
            [self.navigationController pushViewController:faq animated:YES];

        }
            break;
        default:
            break;
    }
    
}


-(void)setImgBtn:(DashboradCollection *)filteCellObj{
    NSInteger NoForBtn = filteCellObj.btnImg.tag;
    
    switch (NoForBtn) {
      
        case 0:
            filteCellObj.btnImg.image = [UIImage imageNamed:@"ic_service_request"];
            break;
            
        case 1:
            filteCellObj.btnImg.image = [UIImage imageNamed:@"ic_complaints"];
            break;
            
        case 2:
            filteCellObj.btnImg.image = [UIImage imageNamed:@"ic_suggestions"];
            break;
            
        case 3:
            filteCellObj.btnImg.image = [UIImage imageNamed:@"ic_enquiry"];
            break;
          
        case 4:
            filteCellObj.btnImg.image = [UIImage imageNamed:@"ic_services"];
            break;
            
        case 5:
            filteCellObj.btnImg.image = [UIImage imageNamed:@"ic_about"];
            break;
        case 6:
            filteCellObj.btnImg.image = [UIImage imageNamed:@"ic_faq"];
            break;
            
        default:
            break;
    }
}

-(void)setTitleForBtn:(DashboradCollection *)filteCellObj{
    NSInteger NoForBtn = filteCellObj.lblBtnTitle.tag;
    //FTA Services, Complaints, Suggestions, Enquiry, About FTA, FAQ, Service Request
    switch (NoForBtn) {
       
        case 0:
            //filteCellObj.lblBtnTitle.text = NSLocalizedString(@"Service Request", @"");
            filteCellObj.lblBtnTitle.text = [MCLocalization stringForKey:@"Service Request"];

            break;
            
        case 1:
          //  filteCellObj.lblBtnTitle.text =NSLocalizedString(@"Complaints", @"");
            
            filteCellObj.lblBtnTitle.text = [MCLocalization stringForKey:@"Complaints"];
            break;
            
        case 2:
           // filteCellObj.lblBtnTitle.text = NSLocalizedString(@"Suggestions", @"");
            
             filteCellObj.lblBtnTitle.text = [MCLocalization stringForKey:@"Suggestions"];
            break;
            
        case 3:
           // filteCellObj.lblBtnTitle.text = NSLocalizedString(@"Enquiry", @"");
            filteCellObj.lblBtnTitle.text = [MCLocalization stringForKey:@"Enquiry"];
            
            break;
            
        case 4:
           // filteCellObj.lblBtnTitle.text = NSLocalizedString(@"FTA Services", @"");
            
              filteCellObj.lblBtnTitle.text = [MCLocalization stringForKey:@"FTA Services"];
            break;
        case 5:
           // filteCellObj.lblBtnTitle.text = NSLocalizedString(@"About FTA", @"");
              filteCellObj.lblBtnTitle.text = [MCLocalization stringForKey:@"About FTA"];
            
            break;
        case 6:
           // filteCellObj.lblBtnTitle.text = NSLocalizedString(@"FAQ", @"");
             filteCellObj.lblBtnTitle.text = [MCLocalization stringForKey:@"FAQ"];
            
            break;
            
        default:
            break;
    }
}
/*
-(void)setTitleForBtn:(DashboradCollection *)filteCellObj{
    NSInteger NoForBtn = filteCellObj.lblBtnTitle.tag;
    //FTA Services, Complaints, Suggestions, Enquiry, About FTA, FAQ, Service Request
    switch (NoForBtn) {
            
        case 0:
            filteCellObj.lblBtnTitle.text = NSLocalizedString(@"Service Request", @"");
           
            
            break;
            
        case 1:
              filteCellObj.lblBtnTitle.text =NSLocalizedString(@"Complaints", @"");
            
           
            break;
            
        case 2:
             filteCellObj.lblBtnTitle.text = NSLocalizedString(@"Suggestions", @"");
            
          
            break;
            
        case 3:
            filteCellObj.lblBtnTitle.text = NSLocalizedString(@"Enquiry", @"");
           
            
            break;
            
        case 4:
             filteCellObj.lblBtnTitle.text = NSLocalizedString(@"FTA Services", @"");
            
                       break;
        case 5:
            filteCellObj.lblBtnTitle.text = NSLocalizedString(@"About FTA", @"");
           
            
            break;
        case 6:
             filteCellObj.lblBtnTitle.text = NSLocalizedString(@"FAQ", @"");
           
            
            break;
            
        default:
            break;
    }
}*/

- (void)updateTabContent
{
    [self.collectionViewDasboard reloadData];
}


#pragma mark - Api request Methods
-(void)getAcctByPSRMIdApi:(NSString *)psrmId{
    
    __weak typeof(self) weakSelf = self;
    
    
    [ITSClient getAccountUsingPSRMid:@"pass psrm id" andPageSize:@"10" andStartRowNum:@"0" andCompletionHandler:^(id result, NSError *error) {
        if (error) {
            
            DDLogInfo(@"error is %@",error.localizedDescription);
            [weakSelf.view setUserInteractionEnabled:YES];
        }else{
            NSLog(@"responce is %@",(NSDictionary *)result);
            NSDictionary *respDict = (NSDictionary *)result;
            getAcctByPSRMIdApiModel *getAcctByPSRMIdApiModelObj =[[getAcctByPSRMIdApiModel alloc] initWithDictionary:[respDict valueForKeyPath:@"SiebelMessageOut.MoF Contact"]];
            [accForPsrmIdArray addObjectsFromArray:getAcctByPSRMIdApiModelObj.mofListWrapper.items];
            NSLog(@"accForPsrmId is %@",accForPsrmIdArray);
            [weakSelf.view setUserInteractionEnabled:YES];
        }
    }];
    /*
    [ITSClient getAccountUsingPSRMid:psrmId andCompletionHandler:^(id result, NSError *error) {
        
        
        if (error) {
            
            DDLogInfo(@"error is %@",error.localizedDescription);
            [weakSelf.view setUserInteractionEnabled:YES];
        }else{
            NSLog(@"responce is %@",(NSDictionary *)result);
            NSDictionary *respDict = (NSDictionary *)result;
            getAcctByPSRMIdApiModel *getAcctByPSRMIdApiModelObj =[[getAcctByPSRMIdApiModel alloc] initWithDictionary:[respDict valueForKeyPath:@"SiebelMessageOut.MoF Contact"]];
            [accForPsrmIdArray addObjectsFromArray:getAcctByPSRMIdApiModelObj.mofListWrapper.items];
            NSLog(@"accForPsrmId is %@",accForPsrmIdArray);
            [weakSelf.view setUserInteractionEnabled:YES];
        }
        
    }];*/
}
/*
-(void)srLinkedAccApiReq:(NSString *)srType{
    [ITSClient fetchSrLinkedAcc:srType completionHandler:^(id result, NSError *error) {
        NSLog(@" srLinkedAccApiReq responce of sr account %@",(NSDictionary *)result);
    }];
}*/
-(void)listOfServiceReq:(NSString *)idForSr{
    [ITSClient getListOfSrReq:idForSr andCompletionHandler:^(id result, NSError *error) {
        NSLog(@"listOfServiceReq responce is %@",(NSDictionary *)result);
        NSDictionary *respDict = (NSDictionary *)result;
        getAcctByPSRMIdApiModel *getAcctByPSRMIdApiModelObj =[[getAcctByPSRMIdApiModel alloc] initWithDictionary:[respDict valueForKeyPath:@"SiebelMessageOut.MoF Contact"]];
        [accForListSrArray addObjectsFromArray:getAcctByPSRMIdApiModelObj.mofListWrapper.items];
        NSLog(@"accForPsrmId is %@",accForListSrArray);
    }];
}

#pragma mark -Picker View
-(void)pickerViewForAcc{
    mofAccPicker = [[UIPickerView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-200, self.view.frame.size.width, 200)];
    mofAccPicker.backgroundColor=[UIColor whiteColor];
//    dispatch_async(dispatch_get_main_queue(), ^{
//        [mofAccPicker selectRow:0 inComponent:0 animated:YES];
//        [self pickerView:mofAccPicker didSelectRow:0 inComponent:0];
//    });
    
    
    [mofAccPicker setDelegate:self];
    [mofAccPicker setDataSource:self];
    
    toolBarAcc = [[UIToolbar alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-244, self.view.frame.size.width, 44)];
    [toolBarAcc setTintColor:[UIColor colorWithRed:225/255.0 green:151/255.0 blue:62/255.0 alpha:1.0]];
    UIBarButtonItem *doneBtn = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(doneMethod)];
    UIBarButtonItem *cancelBtn =[[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(dismissPicker)];
    UIBarButtonItem *spaceBtn = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    [toolBarAcc setItems:[NSArray arrayWithObjects:cancelBtn,spaceBtn,doneBtn, nil]];
    
    [self.view addSubview:mofAccPicker];
    [self.view addSubview:toolBarAcc];
}
-(void)dismissPicker{
    NSLog(@"dismiss clicked");
    [toolBarAcc removeFromSuperview];
    [mofAccPicker removeFromSuperview];
}
-(void)doneMethod{
    NSLog(@"done Clicked");
    //call FTA contact linked to account api call
  //  [self srLinkedAccApiReq:@"pass sr Type"];
    
    [toolBarAcc removeFromSuperview];
    [mofAccPicker removeFromSuperview];
}

#pragma mark - PickerView Delegate Method
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
   return [accArray count];
}
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return [accArray objectAtIndex:row];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    NSString *selectedAcc =[accArray objectAtIndex:row];
}
@end
