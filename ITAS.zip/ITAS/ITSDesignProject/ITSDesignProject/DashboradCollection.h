//
//  DashboradCollection.h
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 14/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DashboradCollection : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIImageView *btnImg;
@property (strong, nonatomic) IBOutlet UILabel *lblBtnTitle;

@end
