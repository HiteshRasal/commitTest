//
//  ITSClient.h
//  ITSDesignProject
//
//  Created by roshan on 24/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <Foundation/Foundation.h>
#define timeOut 20
@interface ITSClient : NSObject

+(void)authenticateLogin:(NSMutableDictionary *)dictionary withHeaders:(NSDictionary *)headers completionHandler:(void(^)(id result,NSError *error))handler;
+(NSDictionary *)headers;
+(NSDictionary *)FormHeaders;

+(void)getProfileReq:(NSMutableDictionary *)headerDict andCompletionHandler:(void(^)(id result ,NSError *error))handler;

+(void)getAccountsReq:(NSMutableDictionary *)headerDict andInpParameter:(NSMutableDictionary *)inpParameter andCompletionHandler:(void(^)(id result,NSError *error))handler;
+(void)getAccountDetailsReq:(NSMutableDictionary *)headerDict andInpParameter:(NSString *)accId andCompletionHandler:(void(^)(id result,NSError *error))handler;
+(void)getListOfSrReq:(NSString *)integrationId andCompletionHandler:(void(^)(id result ,NSError *error))handler;

+(void)registration;

+(NSDictionary *)profileheaders:(NSString *)accesstoken;
+(NSMutableDictionary *)headerDictForPSRMApi;
+(NSMutableDictionary *)headerDictForSibelApi;


+(NSDictionary *)siebelServiceRequestwithContactid:(id)contactId;

+(void)getFTASiebelService:(NSDictionary *)headers andContactid:(NSString *)contactId completionHandler:(void(^)(id result,NSError *error))handler;

+(void)fetchListingForType:(NSString *)srType andContactid:(NSString *)contactId completionHandler:(void(^)(id result,NSError *error))handler;

+(void)fetchSrLinkedAcc:(NSString *)srType andAccId:(NSString *)accId completionHandler:(void (^)(id result, NSError *error))handler;
+(void)getAccountUsingPSRMid:(NSString *)psrmId andCompletionHandler:(void(^)(id result,NSError *error))handler;
+(void)getAccountUsingPSRMid:(NSString *)psrmId andPageSize:(NSString *)pageSize andStartRowNum:(NSString *)startRowNum andCompletionHandler:(void(^)(id result,NSError *error))handler;

@end
