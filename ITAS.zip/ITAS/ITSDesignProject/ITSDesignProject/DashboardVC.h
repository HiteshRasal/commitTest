//
//  DashboardVC.h
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 14/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ITParentTabVC.h"
@interface DashboardVC : ITParentTabVC <UICollectionViewDelegate,UICollectionViewDataSource,UIPickerViewDelegate,UIPickerViewDataSource>
@property (strong, nonatomic) IBOutlet UICollectionView *collectionViewDasboard;
@property (weak, nonatomic) IBOutlet HomeNavigationBar *lblTitle;

@end
