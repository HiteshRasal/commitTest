//
//  SettingsVC.h
//  ITSDesignProject
//
//  Created by Nagabhushana Rao Vaddi on 16/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsVC : UIViewController
@property (strong, nonatomic) IBOutlet UIButton *btnEng;
@property (strong, nonatomic) IBOutlet UIButton *btnArabic;

@property (strong, nonatomic) IBOutlet UIButton *btnLogout;
@property (strong, nonatomic) IBOutlet UILabel *lblLanguage;
@property (strong, nonatomic) IBOutlet UIImageView *imgBtnEng;
@property (strong, nonatomic) IBOutlet UIImageView *imgBtnArabic;

@end
