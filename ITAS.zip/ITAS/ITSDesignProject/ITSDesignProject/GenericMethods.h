//
//  GenericMethods.h
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 19/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface GenericMethods : NSObject

+(void)alertWithOneBtn:(NSString *)title andMsg:(NSString *)message andFirstBtnTitle:(NSString *)firstBtnTitle  andViewController:(UIViewController *)currentVc andCompletionHandler:(void (^)(BOOL result))completionHandler;
+(BOOL)checkDocDirPath:(NSString *)name;
+(NSData *)fetchDataFromDocDir:(NSString *)pathComponent;
+(NSString *)docDirFilePath:(NSString *)strForPathComponet;
+(void)reloadRootViewController;
+(void)storeLangAndLangCode:(int)intForLangCode andkeyForInt:(NSString *)keyForInt andStoreLangVal:(NSString *)langVal andstoreLangKey:(NSString *)langKey;
@end
