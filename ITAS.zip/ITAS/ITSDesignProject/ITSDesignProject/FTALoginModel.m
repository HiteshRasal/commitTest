//
//  FTALoginModel.m
//  FTA
//
//  Created by Hitesh Rasal on 27/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import "FTALoginModel.h"

@implementation FTALoginModel

-(PKDictionaryListWrapper *)mofListWrapper{
    if ([[self valueForKey:@"MoF Account"] isKindOfClass:[NSDictionary class]])  {
        NSMutableArray *mofArray =[[NSMutableArray alloc] init];
        [mofArray addObject:[self valueForKey:@"MoF Account"]];
        [self setValue:mofArray forKey:@"MoF Account"];
        return [self dictionaryListWrapperWithItemOfType:[MofAcc class] forKey:@"MoF Account"];
    }else{
        return [self dictionaryListWrapperWithItemOfType:[MofAcc class] forKey:@"MoF Account"];
    }
}

-(NSString *)IntegrationId{
    return [self stringForKey:@"Integration Id"];
}
-(void)setIntegrationId:(NSString *)IntegrationId{
    [self.dictionary setValue:IntegrationId forKey:@"Integration Id"];
}

@end

@implementation MofAcc
-(NSString *)Id{
    return [self stringForKey:@"Id"];
}
-(void)setId:(NSString *)Id{
    [self.dictionary setValue:Id forKey:@"Id"];
}

-(NSString *)AccNameArabic{
    return [self stringForKey:@"Name Arabic"];
}
-(void)setAccNameArabic:(NSString *)AccNameArabic{
    [self.dictionary setValue:AccNameArabic forKey:@"Name Arabic"];
}

-(NSString *)TaxIDNumber{
    return [self stringForKey:@"Tax ID Number"];
}
-(void)setTaxIDNumber:(NSString *)TaxIDNumber{
    [self.dictionary setValue:TaxIDNumber forKey:@"Tax ID Number"];
}

-(NSString *)TRNo{
    return [self stringForKey:@"TR No"];
}
-(void)setTRNo:(NSString *)TRNo{
    [self.dictionary setValue:TRNo forKey:@"TR No"];
}

@end
