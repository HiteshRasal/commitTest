//
//  PsrmAccListVC.h
//  FTA
//
//  Created by Hitesh Rasal on 29/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PsrmAccListVC : UIViewController<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *tableView;

@end
