//
//  DashboardTabVC.h
//  Tyunami
//
//  Created by Bhavin Trivedi on 7/10/17.
//  Copyright © 2017 Pankanis Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DashboardVC.h"
#import "ITCallVC.h"
#import "ITContactVC.h"
#import "ITLanguageVC.h"
#import "ITHappinessVC.h"
#import "ContactVC.h"

@interface ITTabBarController : UITabBarController<UITabBarDelegate,UITabBarControllerDelegate>
@property DashboardVC * homeVC;
@property ITCallVC * callVC;
@property ContactVC * contactVC;
@property ITLanguageVC * languageVC;
@property ITHappinessVC * happinessVC;
@end
