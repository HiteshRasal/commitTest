//
//  TYTabBarHandler.h
//  Tyunami
//
//  Created by Bhavin Trivedi on 7/10/17.
//  Copyright © 2017 Pankanis Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTabBarController.h"

@interface ITTabBarHandler : NSObject
+(instancetype)sharedInstance;
@property (strong, nonatomic) ITTabBarController * tabVC;
-(void)switchToTab:(int)index;
@end
