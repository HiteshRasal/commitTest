
//  DashboardTabVC.m
//  Tyunami
//
//  Created by Bhavin Trivedi on 7/10/17.
//  Copyright © 2017 Pankanis Technologies. All rights reserved.
//

#import "ITTabBarController.h"
#import "ContactVC.h"

@interface ITTabBarController () <UITabBarControllerDelegate>
{
    UINavigationController * Contnavc;
}
@end

@implementation ITTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [[UIView appearanceWhenContainedIn:[UIAlertView class], nil] setTintColor:RGB(221, 156, 63)] ;
    
    [self setUpTabBar];
    


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)setUpTabBar {
    
    
    // Get Root Tab Controllers
    _homeVC = INSTANTIATE_DASHBOARD(@"DashboardVC");
    _callVC = INSTANTIATE_DASHBOARD(@"ITCallVC");
    _contactVC = INSTANTIATE(@"ContactVC");
    _languageVC = INSTANTIATE_DASHBOARD(@"ITLanguageVC");
    _happinessVC = INSTANTIATE_DASHBOARD(@"ITHappinessVC");
    

    
    UINavigationController * navc=[[UINavigationController alloc]initWithRootViewController:_homeVC];
    
    
    UINavigationController * callnavc=[[UINavigationController alloc]initWithRootViewController:_callVC];
    
    Contnavc=[[UINavigationController alloc]initWithRootViewController:_contactVC];
    
    UINavigationController * langnavc=[[UINavigationController alloc]initWithRootViewController:_languageVC];
    UINavigationController * happnav=[[UINavigationController alloc]initWithRootViewController:_happinessVC];
  
   NSArray * controllers = [NSArray arrayWithObjects:navc,Contnavc,_callVC,_happinessVC,_languageVC,nil
                             ];
    [self setViewControllers:controllers];
    
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor darkGrayColor] }
                                             forState:UIControlStateNormal];
  
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : RGB(21,24,28) }
                                             forState:UIControlStateSelected];
    UITabBarItem * homeItem = self.tabBar.items[0];
    homeItem.image = [[UIImage imageNamed:@"home_tab"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    homeItem.title =@"Home";
    homeItem.tag = 0;
    
    
   
    UITabBarItem * callItem = self.tabBar.items[2];
    callItem.image=[[UIImage imageNamed:@"call_tab"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    callItem.title =@"Call";
    callItem.tag = 1;
 
    
    UITabBarItem * contactUsItem = self.tabBar.items[1];
     contactUsItem.image= [[UIImage imageNamed:@"contact_us_tab"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    contactUsItem.title =@"Contact Us";
    contactUsItem.tag = 2;
    
    UITabBarItem * languageItem = self.tabBar.items[4];
    languageItem.image=
    [[UIImage imageNamed:@"language_tab"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    languageItem.title =@"Language";
    languageItem.tag = 3;
    
    UITabBarItem * happinessItem = self.tabBar.items[3];
    happinessItem.image=
    [[UIImage imageNamed:@"happiness_tab"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    happinessItem.title =@"Happiness";
    happinessItem.tag = 4;
    
    self.selectedIndex = 0;
    
    self.delegate = self;
   
}

-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    NSLog(@"tab bar button tap");
   
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    
    [def setObject: [NSNumber numberWithInteger: self.selectedIndex]
             forKey:@"activeTab"];
    
    [def synchronize];
      
    if(item.tag==2){
       

    }
 
    else if(item.tag==1){
     
      UIAlertController * alert=[UIAlertController alertControllerWithTitle:@"Contact Customer Service"
                                                                    message:@"+1234567890"
                                                             preferredStyle:UIAlertControllerStyleAlert];
      [alert.view setTintColor:RGB(221, 156, 63)];
      
      UIAlertAction* yesButton = [UIAlertAction actionWithTitle:@"Call"
                                                          style:UIAlertActionStyleDefault
                                                        handler:^(UIAlertAction * action)
      {
          
          NSURL *url = [NSURL URLWithString:@"tel://+1234567890"];
          [[UIApplication sharedApplication] openURL:url];

          NSLog(@"you pressed Yes");
          
          
      }];
      
      UIAlertAction* noButton = [UIAlertAction actionWithTitle:@"Cancel"
                                                         style:UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction * action)
      {
          
          NSLog(@"you pressed Cancel");
          
          int activeTab = [(NSNumber*)[def objectForKey:@"activeTab"] intValue];
          
          self.selectedIndex = activeTab;
          
    }];
      
      [alert addAction:yesButton];
      [alert addAction:noButton];
      
      [self presentViewController:alert animated:YES completion:nil];
      
  }
    
    
    if ([[MCLocalization sharedInstance].language isEqualToString:@"en"])
    {
        [MCLocalization sharedInstance].language = @"ru";
       // [tabBarItem0 setImage:[[UIImage imageNamed:@"iconGray.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    }
    else
    {
        [MCLocalization sharedInstance].language = @"en";
       // [tabBarItem0 setImage:[[UIImage imageNamed:@"iconGray.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    }
    /*
    
    [tabBarItem0 setSelectedImage:[[UIImage imageNamed:@"iconBlue.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
     */
    
    
}

-(void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    switch (alertView.tag) {
        case 1:
            if (buttonIndex == 1) {
                NSURL *url = [NSURL URLWithString:@"tel://+1234567890"];
                [[UIApplication sharedApplication] openURL:url];
            }
            break;
        default:
            break;
    }
}

- (void)tabBarController:(UITabBarController *)tabBarController
 didSelectViewController:(UIViewController *)viewController
{
    NSLog(@"controller class: %@", NSStringFromClass([viewController class]));
    NSLog(@"controller title: %@", viewController.title);
    
    if (viewController == tabBarController.moreNavigationController)
    {
        tabBarController.moreNavigationController.delegate = self;
    }
}

- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController
{
    //Perform Custom Action here...
    
    if(![viewController isKindOfClass:[DashboardVC class]]){
        
         return NO;
    }
    
   return YES;
    
}
-(UITabBarController *)getTabbarController
{
    NSLog(@"check the childviewControllers%@",ITSApplication.revealViewController.childViewControllers);
    
    return [ITSApplication.revealViewController.childViewControllers objectAtIndex:1];
    
}

@end
