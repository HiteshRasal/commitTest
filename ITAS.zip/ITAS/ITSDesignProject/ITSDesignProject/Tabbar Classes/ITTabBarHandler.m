//
//  TYTabBarHandler.m
//  Tyunami
//
//  Created by Bhavin Trivedi on 7/10/17.
//  Copyright © 2017 Pankanis Technologies. All rights reserved.
//

#import "ITTabBarHandler.h"

@implementation ITTabBarHandler

+(instancetype)sharedInstance {
    
    static ITTabBarHandler *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[ITTabBarHandler alloc] init];
        
    });
    return sharedInstance;
}
-(void)switchToTab:(int)index {
    _tabVC.selectedIndex = index;
}

@end
