//
//  ExpandableTableView.h
//  DemoCellExpand
//
//  Created by Hitesh Rasal on 28/04/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ExpandableTableViewHeaderView : UITableViewHeaderFooterView

@end

@interface ExpandableTableView : UITableView
/*
if set No - only ope section open
if set Yes - open multiple section
*/
@property (nonatomic) BOOL allowMultipleSectionsOpen;

/*
If set to YES, one section will always be open.
If set to NO, all sections can be closed.
*/
@property (nonatomic) BOOL keepOneSectionOpen;

/*
 @desc  Defines which sections should be open the first time the
 table is shown.
 
 Must be set before any data is loaded.
 */
@property (strong, nonatomic, nullable) NSSet <NSNumber *> *initialOpenSections;

/*
Enables the fading of cells for the last two rows of the
table. The fix can remove some of the animation clunkyness
that happens at the last table view cells.
*/
@property (nonatomic) BOOL enableAnimationFix;

/*!
Checks whether the provided section is open or not
return yes if Open
return No if Close
*/
- (BOOL)isSectionOpen:(NSInteger)section;

/*!
tapping of the header in the provided section.
*/
- (void)toggleSection:(NSInteger)section;

/*!
Finds the section of a header view.
@returns The section of the header view.
*/
- (NSInteger)sectionForHeaderView:(nonnull UITableViewHeaderFooterView *)headerView;


@end

@protocol ExpandableTableViewDelegate <NSObject>

@optional

/*!
 @desc  Implement to respond to which sections can be interacted with.
 
 If NO is returned for a section, the section can neither be opened or closed.
 It stays in it's initial state no matter what.
 
 Use 'initialOpenSections' to mark a section open from the start.
 
 The default return value is YES.
 */
- (BOOL)tableView:(nonnull ExpandableTableView *)tableView canInteractWithHeaderAtSection:(NSInteger)section;

- (void)tableView:(nonnull ExpandableTableView *)tableView willOpenSection:(NSInteger)section withHeader:(nullable UITableViewHeaderFooterView *)header;
- (void)tableView:(nonnull ExpandableTableView *)tableView didOpenSection:(NSInteger)section withHeader:(nullable UITableViewHeaderFooterView *)header;

- (void)tableView:(nonnull ExpandableTableView *)tableView willCloseSection:(NSInteger)section withHeader:(nullable UITableViewHeaderFooterView *)header;
- (void)tableView:(nonnull ExpandableTableView *)tableView didCloseSection:(NSInteger)section withHeader:(nullable UITableViewHeaderFooterView *)header;

@end




