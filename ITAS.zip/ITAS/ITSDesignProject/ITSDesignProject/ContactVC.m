//
//  ContactVC.m
//  ITSDesignProject
//
//  Created by roshan on 17/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ContactVC.h"
#import "ContactCell.h"
#import "LocationMapVC.h"
@interface ContactVC ()

@end

@implementation ContactVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"Contact Us";
    UINib *nib = [UINib nibWithNibName:NSStringFromClass([ContactCell class]) bundle:[NSBundle mainBundle]];
    [self.ContactTableView registerNib:nib forCellReuseIdentifier:NSStringFromClass([ContactCell class])];
    self.homeNavBar.lblTitle.text=@"Contact Us";

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 18)];
   UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 20, tableView.frame.size.width, 18)];
    [label setFont:[UIFont boldSystemFontOfSize:16]];
    NSString *string;
    if(section==0){
        string =@"Dubai";
}
    else{
        string=@"Abu Dhabi";
    }
    [label setText:string];
    [label setTextColor:[UIColor whiteColor]];
    [view addSubview:label];
    [view setBackgroundColor:RGB(221, 156, 63)];
    return view;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
      ContactCell   *cell  = (ContactCell *)[self.ContactTableView dequeueReusableCellWithIdentifier:NSStringFromClass([ContactCell class])];
    
    cell.LocationBtn.tag = indexPath.row;
    
    cell.handler = ^(id sender) {
        
        if(indexPath.section==0){
        LocationMapVC * locMapVc=INSTANTIATE(@"LocationMapVC");
        locMapVc.lattitude=25.2048;
        locMapVc.longitude=55.2708;
        locMapVc.Pintitle=@"Dubai";
           
        [self.navigationController pushViewController:locMapVc animated:YES];
        }
        else{
            LocationMapVC * locMapVc=INSTANTIATE(@"LocationMapVC");
            locMapVc.lattitude=24.4539;
            locMapVc.longitude=54.3773;
            locMapVc.Pintitle=@"Abu Dhabi";
            
            [self.navigationController pushViewController:locMapVc animated:YES];
            
        }
        
    };

    
    return cell;
}



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 50.0f;
}





@end
