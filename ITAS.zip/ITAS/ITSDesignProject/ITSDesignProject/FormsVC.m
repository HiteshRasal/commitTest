//
//  FormsVC.m
//  ITSDesignProject
//
//  Created by Nagabhushana Rao Vaddi on 16/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "FormsVC.h"
#import "FormListCell.h"
#import "LanguageManager.h"

@interface FormsVC (){
    NSMutableDictionary *formListDict;
    NSMutableArray *formArray;
    NSMutableDictionary *formListItemDict;
    BOOL isFilter;
}

@end

@implementation FormsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSInteger langCode = [[[NSUserDefaults standardUserDefaults] valueForKey:@"LangCode"] integerValue];
    [LanguageManager saveLanguageByIndex:langCode];
    self.title = NSLocalizedString(@"Forms List", @"");
    _filterSearchBar.delegate = self;
    _filterSearchBar.placeholder = NSLocalizedString(@"Enter Form Number", @"");
    
    formListDict = [[NSMutableDictionary alloc] init];
    formArray = [[NSMutableArray  alloc] init];
    formListItemDict = [[NSMutableDictionary alloc] init];
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"FormList" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    formListDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    formArray = [formListDict valueForKey:@"data"];
    UINib *formListNib = [UINib nibWithNibName:@"FormListCell" bundle:nil];
    [_tblView registerNib:formListNib forCellReuseIdentifier:@"FormListCellIdef"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Back", @"") style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];

}
-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - UITableView Delegate methods
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (isFilter) {
        return [_filteredArray count];
    }else{
        return [formArray count];
    }
    
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    FormListCell *cell =[ tableView dequeueReusableCellWithIdentifier:@"FormListCellIdef"];
    cell.mainView.layer.cornerRadius = 8.0f;
    cell.mainView.layer.borderColor = [UIColor grayColor].CGColor;
    cell.mainView.layer.borderWidth = 0.5f;
    cell.lblStaticFormNo.text =NSLocalizedString(@"Form Number", @"");
    cell.lblStaticStatus.text =NSLocalizedString(@"Status", @"");
    cell.lblStaticAccountNo.text =NSLocalizedString(@"Account Name", @"");
    cell.lblStaticCreationDate.text =NSLocalizedString(@"Creation Date", @"");
    
    
    if (isFilter) {
        cell.lblStatus.text =[[(NSDictionary *)_filteredArray valueForKey:@"status"] objectAtIndex:indexPath.row];
        cell.lblFormNo.text =[[(NSDictionary *)_filteredArray valueForKey:@"formNo"] objectAtIndex:indexPath.row];
        cell.lblCreationDate.text =[[(NSDictionary *)_filteredArray valueForKey:@"crationDate"] objectAtIndex:indexPath.row];
        cell.lblAccName.text =[[(NSDictionary *)_filteredArray valueForKey:@"accountName"] objectAtIndex:indexPath.row];
        
        if ([[[(NSDictionary *)_filteredArray valueForKey:@"status"] objectAtIndex:indexPath.row] isEqualToString:@"Completed"]) {
            cell.lblStatus.textColor = [UIColor colorWithRed:74/255.0 green:186/255.0 blue:145/255.0 alpha:1.0];
        }else  if ([[[(NSDictionary *)_filteredArray valueForKey:@"status"] objectAtIndex:indexPath.row] isEqualToString:@"In-Progress"]){
            cell.lblStatus.textColor = [UIColor colorWithRed:244/255.0 green:67/255.0 blue:54/255.0 alpha:1.0];
        }
        
    }else{
        cell.lblStatus.text =[[(NSDictionary *)formArray valueForKey:@"status"] objectAtIndex:indexPath.row];
        cell.lblFormNo.text =[[(NSDictionary *)formArray valueForKey:@"formNo"] objectAtIndex:indexPath.row];
        cell.lblCreationDate.text =[[(NSDictionary *)formArray valueForKey:@"crationDate"] objectAtIndex:indexPath.row];
        cell.lblAccName.text =[[(NSDictionary *)formArray valueForKey:@"accountName"] objectAtIndex:indexPath.row];
        
        if ([[[(NSDictionary *)formArray valueForKey:@"status"] objectAtIndex:indexPath.row] isEqualToString:@"Completed"]) {
            cell.lblStatus.textColor = [UIColor colorWithRed:74/255.0 green:186/255.0 blue:145/255.0 alpha:1.0];
        }else  if ([[[(NSDictionary *)formArray valueForKey:@"status"] objectAtIndex:indexPath.row] isEqualToString:@"In-Progress"]){
            cell.lblStatus.textColor = [UIColor colorWithRed:244/255.0 green:67/255.0 blue:54/255.0 alpha:1.0];
        }
    }
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 252.0f;
}


-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    if (searchText.length == 0) {
        isFilter = false;
    }else{
        
        isFilter = true;
        _filteredArray = [[NSMutableArray alloc] init];
        for (NSDictionary *dict in formArray) {
            NSRange nameRange = [[dict valueForKey:@"formNo"] rangeOfString:searchText options:NSCaseInsensitiveSearch];
            if (nameRange.location !=NSNotFound) {
                [self.filteredArray addObject:dict];
            }
        }
        NSLog(@"arrray contains %@",self.filteredArray);
        
    }
    [_tblView reloadData];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
