//
//  ComplaintsVC.m
//  ITSDesignProject
//
//  Created by roshan on 16/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ComplaintsVC.h"
#import "ComplaintListVC.h"
#import "NewServiceRequestVC.h"
@interface ComplaintsVC ()

@end

@implementation ComplaintsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _tableArray=[[NSMutableArray alloc]initWithObjects:@"New Complaints",@"Complaints List" ,nil];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Back", @"") style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
    
    self.title =@"Service Requests";
    NSLog(@"TabName is %@",_TabName);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}




-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _tableArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
   
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ComplaintsVC"];
    
    if (cell == nil)
    {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ComplaintsVC"];
    }

    
    cell.textLabel.text=[_tableArray objectAtIndex:indexPath.row];
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(indexPath.row==0){
        
        NewServiceRequestVC * newservicerequestVC = INSTANTIATE(@"NewServiceRequestVC");
        [self.navigationController pushViewController:newservicerequestVC animated:YES];
    }
    
    else  if(indexPath.row==1){
        
        ComplaintListVC  *complaintsVC=INSTANTIATE(@"ComplaintListVC");
        complaintsVC.TabName=_TabName;
        [self.navigationController pushViewController:complaintsVC animated:YES];
        
    }
}
@end
