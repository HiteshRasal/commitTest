//
//  FeedbackVC.m
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 20/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "FeedbackVC.h"
#import "LanguageManager.h"

@interface FeedbackVC ()

@end

@implementation FeedbackVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSInteger langCode =[[[NSUserDefaults standardUserDefaults] valueForKey:@"LangCode"] integerValue];
    [LanguageManager saveLanguageByIndex:langCode];
    self.title = NSLocalizedString(@"Feedback", @"");
    [DejalBezelActivityView activityViewForView:self.view withLabel:@"Loading" width:100];
    [self loadUrl];
    
    self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Back", @"") style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
}
-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
}
-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)loadUrl{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:feedbackUrl]];
    [_feedbackWebView loadRequest:request];
    [self performSelector:@selector(removeIndicator) withObject:nil afterDelay:0.5];
}

-(void)removeIndicator{
    [DejalKeyboardActivityView removeViewAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
