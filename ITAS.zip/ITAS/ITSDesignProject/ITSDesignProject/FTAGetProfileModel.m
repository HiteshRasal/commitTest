//
//  FTAGetProfileModel.m
//  FTA
//
//  Created by Hitesh Rasal on 27/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import "FTAGetProfileModel.h"

@implementation FTAGetProfileModel

-(NSString *)email{
    return [self stringForKey:@"email"];
}
-(void)setEmail:(NSString *)email{
    [self.dictionary setValue:email forKey:@"email"];
}

-(NSString *)mobilePhoneCountryCode{
    return [self stringForKey:@"mobilePhoneCountryCode"];
}
-(void)setMobilePhoneCountryCode:(NSString *)mobilePhoneCountryCode{
    [self.dictionary setValue:mobilePhoneCountryCode forKey:@"mobilePhoneCountryCode"];
}

-(NSString *)mobilePhoneNumber{
    return [self stringForKey:@"mobilePhoneNumber"];
}
-(void)setMobilePhoneNumber:(NSString *)mobilePhoneNumber{
    [self.dictionary setValue:mobilePhoneNumber forKey:@"mobilePhoneNumber"];
}

-(NSString *)name{
    return [self stringForKey:@"name"];
}
-(void)setName:(NSString *)name{
    [self.dictionary setValue:name forKey:@"name"];
}

-(NSString *)officePhoneCountryCode{
    return [self stringForKey:@"officePhoneCountryCode"];
}
-(void)setOfficePhoneCountryCode:(NSString *)officePhoneCountryCode{
    [self.dictionary setValue:officePhoneCountryCode forKey:@"officePhoneCountryCode"];
}

-(NSString *)officePhoneNumber{
    return [self stringForKey:@"Integration Id"];
}
-(void)setOfficePhoneNumber:(NSString *)officePhoneNumber{
    [self.dictionary setValue:officePhoneNumber forKey:@"officePhoneNumber"];
}

-(NSString *)psrmContactId{
    return [self stringForKey:@"psrmContactId"];
}
-(void)setPsrmContactId:(NSString *)psrmContactId{
    [self.dictionary setValue:psrmContactId forKey:@"psrmContactId"];
}
@end


@implementation AccountsByPsrmIdModel

-(PKDictionaryListWrapper *)accountsListWrapper{
    return [self dictionaryListWrapperWithItemOfType:[AccountsListModel class] forKey:@"accountsList"];
}

@end

@implementation AccountsListModel
-(NSString *)accountId{
    return [self stringForKey:@"accountId"];
}
-(void)setAccountId:(NSString *)accountId{
    [self.dictionary setValue:accountId forKey:@"accountId"];
}

-(NSString *)accountName{
    return [self stringForKey:@"accountName"];
}
-(void)setAccountName:(NSString *)accountName{
    [self.dictionary setValue:accountName forKey:@"accountName"];
}

-(NSString *)accountType{
    return [self stringForKey:@"accountType"];
}
-(void)setAccountType:(NSString *)accountType{
    [self.dictionary setValue:accountType forKey:@"accountType"];
}

-(NSString *)relationshipType{
    return [self stringForKey:@"relationshipType"];
}
-(void)setRelationshipType:(NSString *)relationshipType{
    [self.dictionary setValue:relationshipType forKey:@"relationshipType"];
}

-(NSString *)relationshipStartDate{
    return [self stringForKey:@"relationshipStartDate"];
}
-(void)setRelationshipStartDate:(NSString *)relationshipStartDate{
    [self.dictionary setValue:relationshipStartDate forKey:@"relationshipStartDate"];
}


@end



@implementation AccountsDetailApiModel
-(NSString *)nameArabic{
    return [self stringForKey:@"nameArabic"];
}
-(void)setNameArabic:(NSString *)nameArabic{
    [self.dictionary setValue:nameArabic forKey:@"nameArabic"];
}

-(NSString *)nameEnglish{
    return [self stringForKey:@"nameEnglish"];
}
-(void)setNameEnglish:(NSString *)nameEnglish{
    [self.dictionary setValue:nameEnglish forKey:@"nameEnglish"];
}

-(NSString *)contactNameEnglish{
    return [self stringForKey:@"contactNameEnglish"];
}
-(void)setContactNameEnglish:(NSString *)contactNameEnglish{
    [self.dictionary setValue:contactNameEnglish forKey:@"contactNameEnglish"];
}

-(NSString *)addressLine1{
    return [self stringForKey:@"addressLine1"];
}
-(void)setAddressLine1:(NSString *)addressLine1{
    [self.dictionary setValue:addressLine1 forKey:@"addressLine1"];
}
-(NSString *)addressLine2{
    return [self stringForKey:@"addressLine2"];
}
-(void)setAddressLine2:(NSString *)addressLine2{
    [self.dictionary setValue:addressLine2 forKey:@"addressLine2"];
}
-(NSString *)addressLine3{
    return [self stringForKey:@"addressLine3"];
}
-(void)setAddressLine3:(NSString *)addressLine3{
    [self.dictionary setValue:addressLine3 forKey:@"addressLine3"];
}
-(NSString *)addressLine4{
    return [self stringForKey:@"addressLine4"];
}
-(void)setAddressLine4:(NSString *)addressLine4{
    [self.dictionary setValue:addressLine4 forKey:@"addressLine4"];
}
-(NSString *)country{
    return [self stringForKey:@"country"];
}
-(void)setCountry:(NSString *)country{
    [self.dictionary setValue:country forKey:@"country"];
}
-(NSString *)state{
    return [self stringForKey:@"state"];
}
-(void)setState:(NSString *)state{
    [self.dictionary setValue:state forKey:@"state"];
}
-(NSString *)postalCodeZip{
    return [self stringForKey:@"postalCodeZip"];
}
-(void)setPostalCodeZip:(NSString *)postalCodeZip{
    [self.dictionary setValue:postalCodeZip forKey:@"postalCodeZip"];
}
-(NSString *)city{
    return [self stringForKey:@"city"];
}
-(void)setCity:(NSString *)city{
    [self.dictionary setValue:city forKey:@"city"];
}
-(NSString *)phoneNumber{
    return [self stringForKey:@"phoneNumber"];
}
-(void)setPhoneNumber:(NSString *)phoneNumber{
    [self.dictionary setValue:phoneNumber forKey:@"phoneNumber"];
}
-(NSString *)mobileNumber{
    return [self stringForKey:@"mobileNumber"];
}
-(void)setMobileNumber:(NSString *)mobileNumber{
    [self.dictionary setValue:mobileNumber forKey:@"mobileNumber"];
}
-(NSString *)emailAddress{
    return [self stringForKey:@"emailAddress"];
}
-(void)setEmailAddress:(NSString *)emailAddress{
    [self.dictionary setValue:emailAddress forKey:@"emailAddress"];
}
-(NSString *)contactNameArabic{
    return [self stringForKey:@"contactNameArabic"];
}
-(void)setContactNameArabic:(NSString *)contactNameArabic{
    [self.dictionary setValue:contactNameArabic forKey:@"contactNameArabic"];
}

-(PKDictionaryListWrapper *)AccountDetailTaxTypeListWrapper{
    return [self dictionaryListWrapperWithItemOfType:[AccountsListModel class] forKey:@"taxTypes"];
}
@end

@implementation AccountDetailTaxTypeModel
-(NSString *)trn{
    return [self stringForKey:@"trn"];
}
-(void)setTrn:(NSString *)trn{
    [self.dictionary setValue:trn forKey:@"trn"];
}

-(NSString *)taan{
    return [self stringForKey:@"taan"];
}
-(void)setTaan:(NSString *)taan{
    [self.dictionary setValue:taan forKey:@"taan"];
}

-(NSString *)taxAgentName{
    return [self stringForKey:@"taxAgentName"];
}
-(void)setTaxAgentName:(NSString *)taxAgentName{
    [self.dictionary setValue:taxAgentName forKey:@"taxAgentName"];
}

-(NSString *)registrationDate{
    return [self stringForKey:@"registrationDate"];
}
-(void)setRegistrationDate:(NSString *)registrationDate{
    [self.dictionary setValue:registrationDate forKey:@"registrationDate"];
}

-(NSString *)nextFilingDate{
    return [self stringForKey:@"nextFilingDate"];
}
-(void)setNextFilingDate:(NSString *)nextFilingDate{
    [self.dictionary setValue:nextFilingDate forKey:@"nextFilingDate"];
}

-(NSString *)taxType{
    return [self stringForKey:@"taxType"];
}
-(void)setTaxType:(NSString *)taxType{
    [self.dictionary setValue:taxType forKey:@"taxType"];
}

@end


