//
//  NewServiceRequestVC.m
//  ITSDesignProject
//
//  Created by Nagabhushana Rao Vaddi on 17/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "NewServiceRequestVC.h"
#import "LanguageManager.h"

@interface NewServiceRequestVC (){
    UIPickerView *pickView;
    UIToolbar *toolBarForPicker;
    NSMutableArray *listArray;
    NSMutableArray *storedArray;
}

@end

NSString *gblSelectedType = @"";

@implementation NewServiceRequestVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    _serviceListArray = [[NSMutableArray alloc] init];
    _serviceListItemDict = [[NSMutableDictionary alloc] init];
    _serviceListDict = [[NSMutableDictionary alloc] init];
    storedArray = [[NSMutableArray alloc] init];
    
    NSLog(@"random no is %@",[self generateRandomNo]);

    [self createPicker];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    NSInteger langCode = [[[NSUserDefaults standardUserDefaults] valueForKey:@"LangCode"] integerValue];
    [LanguageManager saveLanguageByIndex:langCode];
    [self setLocalization];
    if (langCode == 3) {
        _txtType.textAlignment = NSTextAlignmentRight;
        _txtCompanyName.textAlignment = NSTextAlignmentRight;
        _txtDes.textAlignment = NSTextAlignmentRight;
        _txtSerReqSor.textAlignment = NSTextAlignmentRight;
        _txtEmailAddress.textAlignment = NSTextAlignmentRight;
    }else if (langCode == 0){
        _txtType.textAlignment = NSTextAlignmentLeft;
        _txtCompanyName.textAlignment = NSTextAlignmentLeft;
        _txtDes.textAlignment = NSTextAlignmentLeft;
        _txtSerReqSor.textAlignment = NSTextAlignmentLeft;
        _txtEmailAddress.textAlignment = NSTextAlignmentLeft;
    }
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Back", @"") style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
}

-(void)setLocalization{
    
    self.title = NSLocalizedString(@"Create Service Request", @"");
    _lblType.text =NSLocalizedString(@"Type", @"");
    _lblCompanyName.text =NSLocalizedString(@"Company Name", @"");
    _lblEmail.text =NSLocalizedString(@"Email Address", @"");
    _lblDes.text =NSLocalizedString(@"Description", @"");
    _lblServiceReq.text =NSLocalizedString(@"Service Request Source", @"");
    [_btnSubmit setTitle:NSLocalizedString(@"Submit", @"") forState:UIControlStateNormal];
    listArray = [NSMutableArray arrayWithObjects:NSLocalizedString(@"Appeal", @""),NSLocalizedString(@"Complaints", @""),NSLocalizedString(@"General Enquiry", @""),NSLocalizedString(@"Objection", @""),NSLocalizedString(@"Reconsideration", @""), nil];
    [_txtType setPlaceholder:NSLocalizedString(@"Select", @"")];
    [_txtCompanyName setPlaceholder:NSLocalizedString(@"Enter Company Name", @"")];
    [_txtDes setPlaceholder:NSLocalizedString(@"Enter Description", @"")];
    [_txtSerReqSor setPlaceholder:NSLocalizedString(@"Enter Service Request Source", @"")];
    [_txtEmailAddress setPlaceholder:NSLocalizedString(@"Enter Email Address", @"")];
    _txtSerReqSor.text =NSLocalizedString(@"Mobile Application", @"");
    
}

-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)createPicker{
    pickView = [[UIPickerView alloc] init];
    pickView.delegate = self;
    pickView.dataSource = self;
    pickView.tag = 1;
    
    toolBarForPicker =[[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    
    [toolBarForPicker setTintColor:[UIColor colorWithRed:219/255.0 green:165/255.0 blue:64/255.0 alpha:1.0]];
    UIBarButtonItem *doneMonthBtn=[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(setSelectedVal)];
    UIBarButtonItem *spaceMonth=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *cancelmonthBtn=[[UIBarButtonItem alloc]initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(dismissPicker)];
    [toolBarForPicker setItems:[NSArray arrayWithObjects:cancelmonthBtn,spaceMonth,doneMonthBtn, nil]];
    
    [_txtType setInputView:pickView];
    [_txtType setInputAccessoryView:toolBarForPicker];
}

-(NSString *)generateRandomNo{
    NSString *min = @"02365"; //Get the current text from your minimum and maximum textfields.
    NSString *max = @"34665";
    
    int randNum = rand() % ([max intValue] - [min intValue]) + [min intValue]; //create the random number.
    
    NSString *num = [NSString stringWithFormat:@"%d", randNum]; //Make the number into a string.
    
    return num;
}

- (IBAction)submitRequest:(id)sender {
    
    if (_txtType.text.length > 0 && _txtCompanyName.text.length > 0 && _txtEmailAddress.text.length > 0 && _txtSerReqSor.text.length > 0 && _txtDes.text.length > 0) {
        [self addDataToJson];
    }else{
         [GenericMethods alertWithOneBtn:NSLocalizedString(@"Message", @"") andMsg:NSLocalizedString(@"All fields are mandatory", @"") andFirstBtnTitle:NSLocalizedString(@"OK", @"") andViewController:self andCompletionHandler:nil];
    }
    
    
    
}
-(void)addDataToJson{
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"dd/MM/yyyy"];
    if ([GenericMethods checkDocDirPath:@"serviceList.json"]) {
        
        
        NSData *data = [GenericMethods fetchDataFromDocDir:@"serviceList.json"];
        NSMutableDictionary *savedDict =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"stored dictionary is %@",savedDict);
        if ([[savedDict valueForKey:@"data"] count] > 0 ) {
            [storedArray addObjectsFromArray:[savedDict valueForKey:@"data"]];
        }
        [_serviceListItemDict setValue:_txtCompanyName.text forKey:@"Company Name"];
        [_serviceListItemDict setValue:[self generateRandomNo] forKey:@"Service Request Number"];
        [_serviceListItemDict setValue:@"Pending" forKey:@"Service Request Status"];
        [_serviceListItemDict setValue:[format stringFromDate:[NSDate date]] forKey:@"Creation date"];
        [storedArray addObject:_serviceListItemDict];
        [_serviceListDict setValue:storedArray forKey:@"data"];
    }else{
        [_serviceListItemDict setValue:_txtCompanyName.text forKey:@"Company Name"];
        [_serviceListItemDict setValue:[self generateRandomNo] forKey:@"Service Request Number"];
        [_serviceListItemDict setValue:@"Pending" forKey:@"Service Request Status"];
        [_serviceListItemDict setValue:[format stringFromDate:[NSDate date]] forKey:@"Creation date"];
        [_serviceListArray addObject:_serviceListItemDict];
        [_serviceListDict setValue:_serviceListArray forKey:@"data"];
    }
    
    
    
    NSData *serviceListData = [NSJSONSerialization dataWithJSONObject:_serviceListDict options:NSJSONWritingPrettyPrinted error:nil];
    NSString *Path = [GenericMethods docDirFilePath:@"serviceList.json"];
    [serviceListData writeToFile:Path atomically:YES];
    
    _callBlockHandler(self);
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)dismissPicker{
    if ([_txtType isFirstResponder])
    {
        [_txtType resignFirstResponder];
    }
}
-(void)setSelectedVal{
    if ([_txtType isFirstResponder]) {
        _txtType.text = gblSelectedType;
        [_txtType resignFirstResponder];
    }
}

#pragma mark - UIPickerView Delegate methods
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return [listArray count];
}
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    return [listArray objectAtIndex:row];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    gblSelectedType = [listArray objectAtIndex:row];
}





@end
