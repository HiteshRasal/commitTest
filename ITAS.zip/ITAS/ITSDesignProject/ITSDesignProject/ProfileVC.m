//
//  ProfileVC.m
//  ITSDesignProject
//
//  Created by Nagabhushana Rao Vaddi on 16/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ProfileVC.h"
#import "LanguageManager.h"

@interface ProfileVC (){
    
}

@end

@implementation ProfileVC

- (void)viewDidLoad {
    [super viewDidLoad];
    NSInteger langCode = [[[NSUserDefaults standardUserDefaults] valueForKey:@"LangCode"] integerValue];
    [LanguageManager saveLanguageByIndex:langCode];
    // Do any additional setup after loading the view.
    self.title =NSLocalizedString(@"Profile", @"");
    _lblContactType.text =NSLocalizedString(@"Contact Type", @"");
    _lblFirstName.text =NSLocalizedString(@"First Name", @"");
    _lblLastName.text =NSLocalizedString(@"Last Name", @"");
    _lblMobile.text =NSLocalizedString(@"Mobile No", @"");
    _lblPhone.text =NSLocalizedString(@"Phone No", @"");
    _lblAccount.text =NSLocalizedString(@"Account", @"");
    _lblAddress.text =NSLocalizedString(@"Address", @"");
    
    
    _labelFirstName.text = @"Priya";
    _labelSecondName.text = @"Nair";
    _labelMobNo.text = @"+971551334208";
    _labelPhoneNo.text = @"+971 44 325 929";
    _labelAddress.text = @"United Arab Emirates";
    _labelAccount.text = @"Administrator";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Back", @"") style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
}
-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/




@end
