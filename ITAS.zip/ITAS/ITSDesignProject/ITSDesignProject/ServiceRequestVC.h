//
//  ServiceRequestVC.h
//  ITSDesignProject
//
//  Created by Nagabhushana Rao Vaddi on 16/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ITParentVC.h"

@interface ServiceRequestVC : ITParentVC <UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>
@property (strong, nonatomic) IBOutlet UISearchBar *searchBarForFilter;
@property (strong, nonatomic) NSMutableArray* filteredTableData;
@property(nonatomic,strong)IBOutlet UITableView *requestsTableView;


@property (weak, nonatomic) IBOutlet HomeNavigationBar *HomeNavBar;

@end
