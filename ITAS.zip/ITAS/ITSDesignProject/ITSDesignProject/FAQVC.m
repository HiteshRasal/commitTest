//
//  FAQServicesVC.m
//  ITSDesignProject
//
//  Created by roshan on 24/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "FAQVC.h"

@interface FAQVC ()

@end

@implementation FAQVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
  NSURL *urlString= [NSURL URLWithString:@"https://www.tax.gov.ae/about.aspx"];
    NSURLRequest *request = [NSURLRequest requestWithURL:urlString];
    [_webView setScalesPageToFit:YES];
    [self.webView loadRequest:request];
   
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"Error : %@",error);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
