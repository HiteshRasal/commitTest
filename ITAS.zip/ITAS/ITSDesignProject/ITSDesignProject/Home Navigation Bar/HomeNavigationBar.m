
#import "HomeNavigationBar.h"

@implementation HomeNavigationBar {



}
- (id)initWithFrame:(CGRect)aRect
{
    if ((self = [super initWithFrame:aRect])) {
        [self xibSetup];
    }
    return self;
}

- (id)initWithCoder:(NSCoder*)coder
{
    if ((self = [super initWithCoder:coder])) {
        [self xibSetup];
    }
    return self;
}



-(void)xibSetup{
    view = [self loadViewFromNib];
    view.frame = self.bounds;
    view.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self addSubview:view];
}

-(UIView*)loadViewFromNib{
        return  [[[NSBundle mainBundle] loadNibNamed:@"HomeNavigationBar" owner:self options:nil] objectAtIndex:0];
}



- (IBAction)buttonSideMenuClicked:(id)sender {
    if(self.buttonSideMenuClicked){
        self.buttonSideMenuClicked();
    }
}

@end
