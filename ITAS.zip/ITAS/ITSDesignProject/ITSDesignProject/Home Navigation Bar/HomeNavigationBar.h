
#import <UIKit/UIKit.h>

@interface HomeNavigationBar : UIView{
    UIView * view;
    
}
@property (nonatomic, copy) void (^buttonSideMenuClicked)(void);
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

@end
