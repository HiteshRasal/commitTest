//
//  ITParentVC.m
//  ITSDesignProject
//
//  Created by roshan on 11/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ITParentVC.h"
#import "UIColor+util.h"

@interface ITParentVC ()

@end

@implementation ITParentVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(localize) name:MCLocalizationLanguageDidChangeNotification object:nil];
    
}
- (void)localize
{
    if ([self respondsToSelector:@selector(updateContent)]) {
         [self updateContent];
    }
   
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
    [[UIView appearanceWhenContainedIn:[UIAlertView class], nil] setTintColor:[UIColor themeColor]] ;
    [self.navigationController.navigationBar setBarTintColor:[UIColor themeColor]];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
