//
//  ShowAccListVC.h
//  FTA
//
//  Created by Hitesh Rasal on 27/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ShowAccListVC : ITParentVC
@property (strong,nonatomic) NSMutableArray *accListArray;
@end
