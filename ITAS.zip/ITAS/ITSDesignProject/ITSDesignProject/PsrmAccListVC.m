//
//  PsrmAccListVC.m
//  FTA
//
//  Created by Hitesh Rasal on 29/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import "PsrmAccListVC.h"
#import "LoginVc.h"
#import "FTAGetProfileModel.h"
#import "AccountListPsrmCell.h"

@interface PsrmAccListVC (){
    NSMutableArray *accountListArray;
    BOOL reloadPage;
    BOOL stopLoadMore;
}

@end

@implementation PsrmAccListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    accountListArray=[[NSMutableArray alloc] init];
    UINib *accListNib =[UINib nibWithNibName:@"AccountListPsrmCell" bundle:nil];
    [_tableView registerNib:accListNib forCellReuseIdentifier:@"AccountListPsrmCellidef"];
    
    [self getAcctListForPsrmId];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [accountListArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"AccountListPsrmCellidef";
    
    AccountListPsrmCell *cell =[tableView dequeueReusableCellWithIdentifier:identifier];
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //TODO call account detail api
    [self getAccountsListReq:@"pass acc id"];
}

#pragma mark - ScrollViewDelegate Methods
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGPoint offset = scrollView.contentOffset;
    CGRect bounds = scrollView.bounds;
    CGSize size = scrollView.contentSize;
    UIEdgeInsets inset = scrollView.contentInset;
    float y = offset.y + bounds.size.height - inset.bottom;
    float h = size.height;
    
    float reload_distance = 15;
    if (!stopLoadMore) {
        if(y > h + reload_distance)
        {
            
            if (!reloadPage) {
                [self getAcctListForPsrmId];
                
                NSLog(@"disPlay array count %lu",(unsigned long)accountListArray.count);
            }
        }
    }
}

#pragma mark - Api request
-(void)getAcctListForPsrmId{
    reloadPage = YES;
    NSMutableDictionary *headerDict =[[NSMutableDictionary alloc] init];
    [headerDict setValue:gblAccessToken forKey:@"Authorization"];
    [headerDict setValue:@"application/json" forKey:@"content-type"];
    NSMutableDictionary *inpParameter =[[NSMutableDictionary alloc] init];
    NSString *offset;
    if (accountListArray.count > 0) {
        offset = [NSString stringWithFormat:@"%d",(int)[accountListArray count]];
    }else{
        offset =@"0";
    }
    
    [inpParameter setValue:@"" forKey:@"Id"];
    [inpParameter setValue:offset forKey:@"Offset"];
    [inpParameter setValue:@"10" forKey:@"Limit"];
    
    [ITSClient getAccountsReq:headerDict andInpParameter:inpParameter andCompletionHandler:^(id result, NSError *error) {
        if (error) {
            reloadPage = NO;
            DLog(@"error %@",error.localizedDescription);
        }else{
            DLog(@"responce is %@",(NSDictionary *)result);
            NSMutableDictionary *respDict = (NSMutableDictionary *)result;
            NSMutableArray *listArray =[[NSMutableArray alloc] init];
            listArray = [respDict valueForKey:@""];
            if (listArray.count > 0) {
                AccountsByPsrmIdModel *accountsByPsrmIdModelObj = [[AccountsByPsrmIdModel alloc] initWithDictionary:respDict];
                [accountListArray addObject:accountsByPsrmIdModelObj.accountsListWrapper.items];
                stopLoadMore = NO;
                reloadPage = NO;
                [_tableView reloadData];
            }else{
                stopLoadMore = YES;
                reloadPage = NO;
            }
            
        }
    }];
    
}

-(void)getAccountsListReq:(NSString *)accId{
    ///test accid = xyz1234
    NSMutableDictionary *headerDict =[[NSMutableDictionary alloc] init];
    [headerDict setValue:gblAccessToken forKey:@"Authorization"];
    [headerDict setValue:@"application/json" forKey:@"content-type"];
    [ITSClient getAccountDetailsReq:headerDict andInpParameter:accId andCompletionHandler:^(id result, NSError *error) {
        if (error) {
            DDLogInfo(@" responce is %@",error.localizedDescription);
        }else{
            DLog(@" responce is %@",(NSDictionary *)result);
        }
    }];
    
}
@end
