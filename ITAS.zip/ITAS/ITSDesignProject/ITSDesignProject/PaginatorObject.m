//
//  PaginatorObject.m
//  FTA
//
//  Created by Hitesh Rasal on 29/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import "PaginatorObject.h"

@implementation PaginatorObject
-(NSString *)pageSize{
    return [self stringForKey:@"pageSize"];
}
-(void)setPageSize:(NSString *)pageSize{
    [self.dictionary setValue:pageSize forKey:@"pageSize"];
}

-(NSString *)startRowNum{
    return [self stringForKey:@"startRowNum"];
}
-(void)setStartRowNum:(NSString *)startRowNum{
    [self.dictionary setValue:startRowNum forKey:@"startRowNum"];
}

@end
