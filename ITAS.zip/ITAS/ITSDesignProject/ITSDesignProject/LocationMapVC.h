//
//  LocationMapVC.h
//  ITSDesignProject
//
//  Created by roshan on 22/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>


@interface LocationMapVC : UIViewController
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property(nonatomic)double longitude,lattitude;
@property(nonatomic)NSString * Pintitle;
@property (weak, nonatomic) IBOutlet HomeNavigationBar *HomeNavBar;
@property (weak, nonatomic) IBOutlet UINavigationBar *navBar;

@end
