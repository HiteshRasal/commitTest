//
//  SplashScreenVC.m
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 20/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "SplashScreenVC.h"
#import "LoginVc.h"
#import "DashboardVC.h"

@interface SplashScreenVC ()

@end
NSString *gblLoginOrNot = @"";
@implementation SplashScreenVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
}
-(void)viewWillAppear:(BOOL)animated{
    [self.navigationController setNavigationBarHidden:YES];
    [self navigateScreen];
   
}
-(void)navigateScreen{
    if ([gblLoginOrNot isEqualToString:@"LoggedIn"]) {
        DashboardVC *dashBoardObj =[self.storyboard instantiateViewControllerWithIdentifier:@"DashboardVC"];
        [self.navigationController pushViewController:dashBoardObj animated:YES];
    }else {
        LoginVc *loginObj = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginVc"];
        [self.navigationController pushViewController:loginObj animated:YES];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
