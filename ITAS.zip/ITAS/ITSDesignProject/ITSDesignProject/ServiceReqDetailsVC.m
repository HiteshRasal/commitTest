//
//  ServiceReqDetailsVC.m
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 17/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ServiceReqDetailsVC.h"
#import "LanguageManager.h"

@interface ServiceReqDetailsVC ()

@end

@implementation ServiceReqDetailsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    NSInteger langCode = [[[NSUserDefaults standardUserDefaults] valueForKey:@"LangCode"] integerValue];
    [LanguageManager saveLanguageByIndex:langCode];
    self.title = NSLocalizedString(@"Service Request Details", @"");
    
    [self setLocalization];
    
    _lblAccNo.text = _accName;
    _lblStatus.text = _status;
    _lblSerReqNo.text = _serReqNo;
    _lblDate.text = _creationDate;
    // Do any additional setup after loading the view.
}
-(void)setLocalization{
    _lblStaticName.text = NSLocalizedString(@"Account Name", @"");
    _lblStaticCreationDate.text = NSLocalizedString(@"Creation Date", @"");
    _lblStaticNo.text = NSLocalizedString(@"Service Request No", @"");
    _lblStaticStatus.text = NSLocalizedString(@"Status", @"");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Back", @"") style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
}
-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
