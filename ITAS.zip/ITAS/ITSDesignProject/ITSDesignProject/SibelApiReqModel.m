//
//  SibelApiReqModel.m
//  FTA
//
//  Created by Hitesh Rasal on 28/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import "SibelApiReqModel.h"

@implementation SibelApiReqModel

@end


@implementation getAcctByPSRMIdApiModel
-(PKDictionaryListWrapper *)mofListWrapper{
    if ([[self valueForKey:@"MoF Account"] isKindOfClass:[NSDictionary class]])  {
        NSMutableArray *mofArray =[[NSMutableArray alloc] init];
        [mofArray addObject:[self valueForKey:@"MoF Account"]];
        [self setValue:mofArray forKey:@"MoF Account"];
        return [self dictionaryListWrapperWithItemOfType:[MofAccForPSRM class] forKey:@"MoF Account"];
    }else{
        return [self dictionaryListWrapperWithItemOfType:[MofAccForPSRM class] forKey:@"MoF Account"];
    }
}

-(NSString *)IntegrationId{
    return [self stringForKey:@"Integration Id"];
}
-(void)setIntegrationId:(NSString *)IntegrationId{
    [self.dictionary setValue:IntegrationId forKey:@"Integration Id"];
}


@end

@implementation MofAccForPSRM
-(NSString *)Id{
    return [self stringForKey:@"Id"];
}
-(void)setId:(NSString *)Id{
    [self.dictionary setValue:Id forKey:@"Id"];
}

-(NSString *)AccNameArabic{
    return [self stringForKey:@"Name Arabic"];
}
-(void)setAccNameArabic:(NSString *)AccNameArabic{
    [self.dictionary setValue:AccNameArabic forKey:@"Name Arabic"];
}

-(NSString *)TaxIDNumber{
    return [self stringForKey:@"Tax ID Number"];
}
-(void)setTaxIDNumber:(NSString *)TaxIDNumber{
    [self.dictionary setValue:TaxIDNumber forKey:@"Tax ID Number"];
}

-(NSString *)TRNo{
    return [self stringForKey:@"TR No"];
}
-(void)setTRNo:(NSString *)TRNo{
    [self.dictionary setValue:TRNo forKey:@"TR No"];
}


@end

@implementation SrLinkAccountToPsrmModel

-(PKDictionaryListWrapper *)serviceRequestListWrapper{
    return [self dictionaryListWrapperWithItemOfType:[ServiceRequestListModel class] forKey:@"Service Request"];
}
@end

@implementation ServiceRequestListModel
-(NSString *)Account{
    return [self stringForKey:@"Account"];
}
-(void)setAccount:(NSString *)Account{
    [self.dictionary setValue:Account forKey:@"Account"];
}

-(NSString *)AccountId{
    return [self stringForKey:@"Account Id"];
}
-(void)setAccountId:(NSString *)AccountId{
    [self.dictionary setValue:AccountId forKey:@"Account Id"];
}-(NSString *)CreatedDate{
    return [self stringForKey:@"Created"];
}
-(void)setCreatedDate:(NSString *)CreatedDate{
    [self.dictionary setValue:CreatedDate forKey:@"Created"];
}

-(NSString *)Description{
    return [self stringForKey:@"Description"];
}
-(void)setDescription:(NSString *)Description{
    [self.dictionary setValue:Description forKey:@"Description"];
}-(NSString *)mofEmailSubject{
    return [self stringForKey:@"MoF Email Subject"];
}
-(void)setMofEmailSubject:(NSString *)mofEmailSubject{
    [self.dictionary setValue:mofEmailSubject forKey:@"MoF Email Subject"];
}

-(NSString *)srNumber{
    return [self stringForKey:@"SR Number"];
}
-(void)setSrNumber:(NSString *)srNumber{
    [self.dictionary setValue:srNumber forKey:@"SR Number"];
}-(NSString *)srType{
    return [self stringForKey:@"SR Type"];
}
-(void)setSrType:(NSString *)srType{
    [self.dictionary setValue:srType forKey:@"SR Type"];
}

-(NSString *)status{
    return [self stringForKey:@"Status"];
}
-(void)setStatus:(NSString *)status{
    [self.dictionary setValue:status forKey:@"Status"];
}-(NSString *)subStatus{
    return [self stringForKey:@"Sub-Status"];
}
-(void)setSubStatus:(NSString *)subStatus{
    [self.dictionary setValue:subStatus forKey:@"Sub-Status"];
}

-(NSString *)trNo{
    return [self stringForKey:@"TR No"];
}
-(void)setTrNo:(NSString *)trNo{
    [self.dictionary setValue:trNo forKey:@"TR No"];
}

@end
