//
//  PaginatorObject.h
//  FTA
//
//  Created by Hitesh Rasal on 29/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import <PankanisAppKit/PankanisAppKit.h>

@interface PaginatorObject : PKDictionaryWrapper
@property (strong,nonatomic) NSString *pageSize;
@property (strong,nonatomic) NSString *startRowNum;

@end
