//
//  ServiceRequestVC.m
//  ITSDesignProject
//
//  Created by Nagabhushana Rao Vaddi on 16/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ServiceRequestVC.h"
#import "ServiceRequestCell.h"
#import "NewServiceRequestVC.h"
#import "ServiceReqDetailsVC.h"
#import "LanguageManager.h"


@interface ServiceRequestVC (){
    NSMutableDictionary *parentDict;
    NSMutableArray *listArray;
    
    BOOL isFilter;
}

@property(nonatomic,strong)NSMutableArray *serviceRequestsArray;

@end

@implementation ServiceRequestVC

#pragma mark -- button actions
-(void)newServiceRequestBarButtonAction
{
    NewServiceRequestVC  *newServiceRequestVC  =  [self.storyboard instantiateViewControllerWithIdentifier:@"NewServiceRequestVC"];
    [self.navigationController pushViewController:newServiceRequestVC animated:YES];
    
    __block NewServiceRequestVC *newSerViceObj;
    newServiceRequestVC.callBlockHandler = ^(id sender){
        newSerViceObj =  sender;
        
    };
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
   
    self.HomeNavBar.lblTitle.text=@"Service Request";

    NSInteger langCode = [[[NSUserDefaults standardUserDefaults] valueForKey:@"LangCode"] integerValue];
    [LanguageManager saveLanguageByIndex:langCode];
    self.title = NSLocalizedString(@"Service Request List", @"");
    
    _searchBarForFilter.delegate = self;
    _searchBarForFilter.placeholder=NSLocalizedString(@"Enter Service Request No", @"");
    parentDict = [[NSMutableDictionary alloc] init];
    listArray = [[NSMutableArray alloc] init];
    UINib *nib = [UINib nibWithNibName:NSStringFromClass([ServiceRequestCell class]) bundle:[NSBundle mainBundle]];
    [self.requestsTableView registerNib:nib forCellReuseIdentifier:NSStringFromClass([ServiceRequestCell class])];
    
  //  self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(newServiceRequestBarButtonAction)];
 //   self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Back", @"") style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
    
   // self.navigationController.navigationBar.backgroundColor=[UIColor redColor];
   // [self.navigationController.navigationBar setBackgroundColor:RGB(221, 156, 63)];
   // [self.navigationController.navigationBar setBarTintColor:RGB(221, 156, 63)];
    
    [iOSHelper performActionInBackground:^{
        if ([GenericMethods checkDocDirPath:@"serviceList.json"]) {
            NSData *data = [GenericMethods fetchDataFromDocDir:@"serviceList.json"];
            parentDict =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
            listArray = [parentDict valueForKey:@"data"];
            
           [iOSHelper performActionOnMainThread:^{
               [_requestsTableView reloadData];

           }];

        }else{
            
            NSString *path =[[NSBundle mainBundle] pathForResource:@"ServiceList" ofType:@"json"];
            NSData *serviceListData =[NSData dataWithContentsOfFile:path];
            NSString *Path = [GenericMethods docDirFilePath:@"serviceList.json"];
            [serviceListData writeToFile:Path atomically:YES];
            
            NSMutableDictionary *respDict =[NSJSONSerialization JSONObjectWithData:serviceListData options:NSJSONReadingMutableLeaves error:nil];
            listArray = [respDict valueForKey:@"data"];
        }

    }];
   
    
    
}
-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (listArray.count > 0) {
        if (isFilter) {
            return self.filteredTableData.count;
        }else{
            return listArray.count;
        }
        
    }
    
    return 0;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ServiceRequestCell   *cell  = (ServiceRequestCell *)[self.requestsTableView dequeueReusableCellWithIdentifier:NSStringFromClass([ServiceRequestCell class])];
    cell.lblStaticCompNo.text =NSLocalizedString(@"Account Name", @"");
    cell.lblStaticCreationDate.text =NSLocalizedString(@"Creation Date", @"");
    cell.lblStaticStatus.text =NSLocalizedString(@"Status", @"");
    cell.lblStaticServReqNo.text =NSLocalizedString(@"Service Request No", @"");
    
    
    if (isFilter) {
        cell.lblAccountName.text = [[(NSDictionary *)_filteredTableData valueForKey:@"Company Name"] objectAtIndex:indexPath.row];
        cell.lblServiceRequestNo.text = [[(NSDictionary *)_filteredTableData valueForKey:@"Service Request Number"] objectAtIndex:indexPath.row];
        cell.lblStatus.text = [[(NSDictionary *)_filteredTableData valueForKey:@"Service Request Status"] objectAtIndex:indexPath.row];
        cell.lblCreationDate.text = [[(NSDictionary *)_filteredTableData valueForKey:@"Creation date"] objectAtIndex:indexPath.row];
       
        if ([[[(NSDictionary *)_filteredTableData valueForKey:@"Service Request Status"] objectAtIndex:indexPath.row] isEqualToString:@"Approved"]) {
            cell.lblStatus.textColor = [UIColor colorWithRed:74/255.0 green:186/255.0 blue:145/255.0 alpha:1.0];
        }else  if ([[[(NSDictionary *)_filteredTableData valueForKey:@"Service Request Status"] objectAtIndex:indexPath.row] isEqualToString:@"Pending"]){
            cell.lblStatus.textColor = [UIColor colorWithRed:244/255.0 green:67/255.0 blue:54/255.0 alpha:1.0];
        }
        
    }else{
        cell.lblAccountName.text = [[(NSDictionary *)listArray valueForKey:@"Company Name"] objectAtIndex:indexPath.row];
        cell.lblServiceRequestNo.text = [[(NSDictionary *)listArray valueForKey:@"Service Request Number"] objectAtIndex:indexPath.row];
        cell.lblStatus.text = [[(NSDictionary *)listArray valueForKey:@"Service Request Status"] objectAtIndex:indexPath.row];
        cell.lblCreationDate.text = [[(NSDictionary *)listArray valueForKey:@"Creation date"] objectAtIndex:indexPath.row];
        
        if ([[[(NSDictionary *)listArray valueForKey:@"Service Request Status"] objectAtIndex:indexPath.row] isEqualToString:@"Approved"]) {
            cell.lblStatus.textColor = [UIColor colorWithRed:74/255.0 green:186/255.0 blue:145/255.0 alpha:1.0];
        }else  if ([[[(NSDictionary *)listArray valueForKey:@"Service Request Status"] objectAtIndex:indexPath.row] isEqualToString:@"Pending"]){
            cell.lblStatus.textColor = [UIColor colorWithRed:244/255.0 green:67/255.0 blue:54/255.0 alpha:1.0];
        }
    }
    
    return cell;
}



- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    ServiceReqDetailsVC *serviceReqDetailsObj = [self.storyboard instantiateViewControllerWithIdentifier:@"ServiceReqDetailsVC"];
    if (isFilter) {
        serviceReqDetailsObj.accName = [[(NSDictionary *)_filteredTableData valueForKey:@"Company Name"] objectAtIndex:indexPath.row];
        serviceReqDetailsObj.serReqNo= [[(NSDictionary *)_filteredTableData valueForKey:@"Service Request Number"] objectAtIndex:indexPath.row];
        serviceReqDetailsObj.status = [[(NSDictionary *)_filteredTableData valueForKey:@"Service Request Status"] objectAtIndex:indexPath.row];
        serviceReqDetailsObj.creationDate = [[(NSDictionary *)_filteredTableData valueForKey:@"Creation date"] objectAtIndex:indexPath.row];
    }else{
        serviceReqDetailsObj.accName = [[(NSDictionary *)listArray valueForKey:@"Company Name"] objectAtIndex:indexPath.row];
        serviceReqDetailsObj.serReqNo = [[(NSDictionary *)listArray valueForKey:@"Service Request Number"] objectAtIndex:indexPath.row];
        serviceReqDetailsObj.status = [[(NSDictionary *)listArray valueForKey:@"Service Request Status"] objectAtIndex:indexPath.row];
        serviceReqDetailsObj.creationDate = [[(NSDictionary *)listArray valueForKey:@"Creation date"] objectAtIndex:indexPath.row];
        
    }
    [self.navigationController pushViewController:serviceReqDetailsObj animated:YES];
}

#pragma mark - UISearchBar Delegate Methods
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    if (searchText.length == 0) {
        isFilter =  false;
    }else{
        isFilter = true;
        self.filteredTableData = [[NSMutableArray alloc] init];
        for (NSDictionary *dict in listArray) {
            NSRange nameRange = [[dict valueForKey:@"Service Request Number"] rangeOfString:searchText options:NSCaseInsensitiveSearch];
            if (nameRange.location !=NSNotFound) {
                [self.filteredTableData addObject:dict];
            }
        }
        
        
        NSLog(@"arrray contains %@",self.filteredTableData);
    }
    [_requestsTableView reloadData];
}







@end
