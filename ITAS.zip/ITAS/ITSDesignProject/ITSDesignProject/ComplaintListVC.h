//
//  ComplaintListVC.h
//  ITSDesignProject
//
//  Created by roshan on 16/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ITParentVC.h"

@interface ComplaintListVC : UIViewController
@property(nonatomic)NSMutableArray * Tabitems;
@property (weak, nonatomic) IBOutlet HomeNavigationBar *HomeNavBar;
@property (strong,nonatomic) NSString *gblAccId;
@property(nonatomic)NSString * TabName;
@end
