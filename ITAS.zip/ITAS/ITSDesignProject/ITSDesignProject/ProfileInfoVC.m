//
//  ProfileInfoVC.m
//  FTA
//
//  Created by Hitesh Rasal on 29/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import "ProfileInfoVC.h"
#import "LabelCell.h"
#import "TwoLabelCell.h"
#import "TexfieldCell.h"

#define LabelCellIdef @"LabelCellIdef"
#define TwoLabelCellIdef @"TwoLabelCellIdef"
#define TexfieldCellIdef @"TexfieldCellIdef"

@interface ProfileInfoVC ()

@end

@implementation ProfileInfoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UINib *labelNib = [UINib nibWithNibName:@"LabelCell" bundle:nil];
    UINib *twoLabelNib = [UINib nibWithNibName:@"TwoLabelCell" bundle:nil];
    UINib *textFieldNib = [UINib nibWithNibName:@"TexfieldCell" bundle:nil];
    [_tableView registerNib:labelNib forCellReuseIdentifier:LabelCellIdef];
    [_tableView registerNib:twoLabelNib forCellReuseIdentifier:TwoLabelCellIdef];
    [_tableView registerNib:textFieldNib forCellReuseIdentifier:TexfieldCellIdef];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 65.0f;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 5;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 0) {
        LabelCell *cell =[tableView dequeueReusableCellWithIdentifier:LabelCellIdef];
        cell.lblTitle.text = @"Name";
        cell.lblValue.text = @"Test User";
       // cell.lblValue.text = ITSApplication.ftaGetProfileModelobj.name;
        return cell;
    }else if (indexPath.row == 1){
        LabelCell *cell =[tableView dequeueReusableCellWithIdentifier:LabelCellIdef];
        cell.lblTitle.text = @"Contact Id";
        cell.lblValue.text = @"xyz";
       //  cell.lblValue.text = ITSApplication.ftaGetProfileModelobj.psrmContactId;
        return cell;
    }else if (indexPath.row == 2){
        TexfieldCell *cell = [tableView dequeueReusableCellWithIdentifier:TexfieldCellIdef];
        cell.lblName.text = @"Email Address";
        cell.txtCustomField.text =  @"test@gamil.com";
         //cell.txtCustomField.text = ITSApplication.ftaGetProfileModelobj.email;
        cell.txtCustomField.tag = indexPath.row;
        cell.txtCustomField.delegate = self;
        return cell;
    }else if (indexPath.row == 3){
        TwoLabelCell *cell = [tableView dequeueReusableCellWithIdentifier:TwoLabelCellIdef];
        cell.lblFirstTitle.text = @"Mobile No";
        cell.lblFirstValue.text = @"1234567890";
       // cell.lblFirstValue.text = ITSApplication.ftaGetProfileModelobj.mobilePhoneNumber;
        cell.lblSecondTitle.text = @"Country Code";
        cell.lblSecondValue.text = @"333";
       // cell.lblSecondValue.text = ITSApplication.ftaGetProfileModelobj.mobilePhoneCountryCode;
        return cell;
    }else if (indexPath.row == 4){
        TwoLabelCell *cell = [tableView dequeueReusableCellWithIdentifier:TwoLabelCellIdef];
        cell.lblFirstTitle.text = @"Office No";
        cell.lblFirstValue.text = @"123456";
       //  cell.lblFirstValue.text = ITSApplication.ftaGetProfileModelobj.officePhoneNumber;
        cell.lblSecondTitle.text = @"Country Code";
        cell.lblSecondValue.text = @"444";
       //  cell.lblSecondValue.text = ITSApplication.ftaGetProfileModelobj.officePhoneCountryCode;
        return cell;
    }
    return nil;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
-(void)textFieldDidEndEditing:(UITextField *)textField{
    NSLog(@"textField Value is %@",textField.text);
}
@end
