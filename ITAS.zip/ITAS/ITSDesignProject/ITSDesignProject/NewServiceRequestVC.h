//
//  NewServiceRequestVC.h
//  ITSDesignProject
//
//  Created by Nagabhushana Rao Vaddi on 17/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//




#import <UIKit/UIKit.h>

extern NSString *gblSelectedType;

typedef void(^blockHandler)(id sender);

@interface NewServiceRequestVC : UIViewController<UIPickerViewDataSource,UIPickerViewDelegate>
@property (strong, nonatomic) IBOutlet UITextField *txtType;
@property (copy,nonatomic) blockHandler callBlockHandler;
@property (strong,nonatomic) NSMutableArray *serviceListArray;
@property (strong,nonatomic) NSMutableDictionary *serviceListDict;
@property (strong,nonatomic) NSMutableDictionary *serviceListItemDict;
@property (strong, nonatomic) IBOutlet UITextField *txtCompanyName;
@property (strong, nonatomic) IBOutlet UILabel *lblType;
@property (strong, nonatomic) IBOutlet UILabel *lblCompanyName;
@property (strong, nonatomic) IBOutlet UILabel *lblEmail;
@property (strong, nonatomic) IBOutlet UILabel *lblServiceReq;
@property (strong, nonatomic) IBOutlet UILabel *lblDes;
@property (strong, nonatomic) IBOutlet UIButton *btnSubmit;
@property (strong, nonatomic) IBOutlet UITextField *txtEmailAddress;
@property (strong, nonatomic) IBOutlet UITextField *txtSerReqSor;
@property (strong, nonatomic) IBOutlet UITextField *txtDes;

@end
