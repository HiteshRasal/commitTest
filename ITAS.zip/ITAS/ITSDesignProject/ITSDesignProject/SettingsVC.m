//
//  SettingsVC.m
//  ITSDesignProject
//
//  Created by Nagabhushana Rao Vaddi on 16/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "SettingsVC.h"
#import "LanguageManager.h"
#import "SplashScreenVC.h"

@interface SettingsVC ()

@end

@implementation SettingsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
    NSInteger langCode = [self langCodeVal:@"LangCode"];
    [LanguageManager saveLanguageByIndex:langCode];
    [self setRadioButtonImg:langCode];
    
    
    self.title = NSLocalizedString(@"Settings", @"");
    _lblLanguage.text = NSLocalizedString(@"Language", @"");
    [_btnLogout setTitle:NSLocalizedString(@"Logout", @"") forState:UIControlStateNormal];
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Back", @"") style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
}
-(void)setRadioButtonImg:(NSInteger )langCode{
    int code = langCode;
    
    switch (code) {
        case 0:
            _imgBtnEng.image = [UIImage imageNamed:@"radio-on-button"];
            _imgBtnArabic.image = [UIImage imageNamed:@"radio-off-button"];
            break;
            
        case 3:
            _imgBtnEng.image = [UIImage imageNamed:@"radio-off-button"];
            _imgBtnArabic.image = [UIImage imageNamed:@"radio-on-button"];
            break;
            
        default:
            break;
    }
    
}

-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)engLangAction:(id)sender {
    [GenericMethods storeLangAndLangCode:0 andkeyForInt:@"LangCode" andStoreLangVal:@"English" andstoreLangKey:@"Lang"];
    NSInteger langCode = [self langCodeVal:@"LangCode"];
    [self setRadioButtonImg:langCode];
    [GenericMethods reloadRootViewController];
}
- (IBAction)arabicLangAction:(id)sender {
    [GenericMethods storeLangAndLangCode:3 andkeyForInt:@"LangCode" andStoreLangVal:@"Arabic" andstoreLangKey:@"Lang"];
    NSInteger langCode = [self langCodeVal:@"LangCode"];
    [self setRadioButtonImg:langCode];
    [GenericMethods reloadRootViewController];
}
- (IBAction)LogOutAction:(id)sender {
    gblLoginOrNot = @"logOut";
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:0] animated:YES];
}
-(NSInteger )langCodeVal:(NSString *)strForKey{
    NSInteger langCode = [[[NSUserDefaults standardUserDefaults] valueForKey:@"LangCode"] integerValue];
    return langCode;
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
