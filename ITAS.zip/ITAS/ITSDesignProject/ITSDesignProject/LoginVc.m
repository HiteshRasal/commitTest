//
//  LoginVc.m
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 14/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "LoginVc.h"
#import "DashboardVC.h"
#import "LanguageManager.h"
#import "SplashScreenVC.h"
#import "ITSClient.h"
#import "FTALoginModel.h"
#import "FTAGetProfileModel.h"
#import "ProfileVC.h"

@interface LoginVc ()
{
    NSString *identifier, *secret;
    
}
@end
NSString *gblPsrmID=@"";
NSString *gblAccessToken=@"";
@implementation LoginVc

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    /*
    [ITSClient getAccountUsingPSRMid:@"hello" andCompletionHandler:^(id result, NSError *error) {
        if (error) {
            NSLog(@"error%@",error.localizedDescription);
        }else{
            FTALoginModel *ftaLoginModelObj =[[FTALoginModel alloc] initWithDictionary:[(NSMutableDictionary *)result valueForKeyPath:@"SiebelMessageOut.MoF Contact"]];
            MofAcc *mofAccModelObj =[ftaLoginModelObj.mofListWrapper objectAtIndex:0];
        }
     
        
    }];*/
    // Do any additional setup after loading the view.
}
-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    _btnSignIn.layer.shadowColor = [UIColor darkGrayColor].CGColor;
    _btnSignIn.layer.shadowOffset = CGSizeMake(0, 0);
    _btnSignIn.layer.shadowRadius = 5;
    _btnSignIn.layer.shadowOpacity = 0.5;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    _txtEmail.text = @"joyson.fernandes@pankanis.com";
    _txtPassWord.text = @"Admin@123";
    
    NSString *langStr = [[NSUserDefaults standardUserDefaults] valueForKey:@"Lang"];
    if (langStr != nil) {
        NSInteger langCode = [[[NSUserDefaults standardUserDefaults] valueForKey:@"LangCode"] integerValue];
        [LanguageManager saveLanguageByIndex:langCode];
        [self setLocalization];
        if (langCode == 3) {
            _txtEmail.textAlignment = NSTextAlignmentRight;
            _txtPassWord.textAlignment = NSTextAlignmentRight;
        }else if (langCode == 0){
            _txtEmail.textAlignment = NSTextAlignmentLeft;
            _txtPassWord.textAlignment = NSTextAlignmentLeft;
        }
        
        
    }
    
    identifier=_txtEmail.text;
    secret=_txtPassWord.text;
    
    
    [self.navigationController setNavigationBarHidden:YES];
}
-(void)setLocalization{
    _lblEmail.text = NSLocalizedString(@"Username", @"");
    _lblPassword.text = NSLocalizedString(@"Password", @"");
    
    [_btnSignIn setTitle:NSLocalizedString(@"SIGN IN", @"") forState:UIControlStateNormal];
    [_txtEmail setPlaceholder:NSLocalizedString(@"Enter Username", @"")];
    [_txtPassWord setPlaceholder:NSLocalizedString(@"Enter Password", @"")];
}



/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
- (IBAction)setArabicLang:(id)sender {
    [GenericMethods storeLangAndLangCode:3 andkeyForInt:@"LangCode" andStoreLangVal:@"Arabic" andstoreLangKey:@"Lang"];
    [GenericMethods reloadRootViewController];
}
- (IBAction)setEngLang:(id)sender {
    [GenericMethods storeLangAndLangCode:0 andkeyForInt:@"LangCode" andStoreLangVal:@"English" andstoreLangKey:@"Lang"];
    [GenericMethods reloadRootViewController];
}

- (IBAction)SignInAction:(id)sender {
    
    
    
     //coment for debug
    //[self authenticateLogin];
    
    
     //till here
    DashboardVC *dashboardVcObj = INSTANTIATE_DASHBOARD(@"DashboardVC");
    
    [self.navigationController  pushViewController:[ITSApplication getSetSWRevealViewController] animated:YES];
    
    
    
//         if (_txtEmail.text.length > 0 && _txtPassWord.text.length > 0 ) {
//         gblLoginOrNot = @"LoggedIn";
//         
//
//         
//         NSMutableDictionary * logindict= [[NSMutableDictionary alloc]initWithObjectsAndKeys:identifier,@"testa@etax.com",secret,@"Coffee@111", nil];
//         
//         NSDictionary *headers = @{ @"content-type": @"application/json",
//         @"cache-control": @"no-cache",
//         @"postman-token": @"2b951c6b-d4a5-5bf1-59eb-04d62e71dbd5" };
//
//         
//        [ITSClient authenticateLogin:logindict withHeaders:headers completionHandler:^(id result, NSError *error) {
//            
//            if(result){
//                
//                NSLog(@"result is %@",result);
//                
//                NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
//                
//                [def setObject: [ result valueForKey:@"accessToken"]
//                        forKey:@"accessToken"];
//                
//                [def synchronize];
//                
//                
//                
//            NSString * accessToken = [def objectForKey:@"accessToken"] ;
//                
//                
//              [ITSClient getProfile:[ITSClient profileheaders:accessToken] completionHandler:^(id result, NSError *error) {
//                  NSLog(@"Get profile response");
//                  
//                  if(result){
//                      NSString * contactid=[result valueForKey:@""];
//                     
//                      
//                [ITSClient getFTASiebelService:[ITSClient headers] andContactid:@"1-45456" completionHandler:^(id result, NSError *error) {
//                     NSLog(@"SiebelService response");
//                 
//                  }];
//                      
//                  }
//                  else if(error){
//                      NSLog(@"Error is %@",error.localizedDescription);
//                  }
//                  
//              }];
//                
//        }
//            
//          else if(error){
//                NSLog(@"error %@",error.localizedDescription);
//            }
//            else{
//                NSLog(@"fdfd");
//            }
//            
//     }];
//       
//        
//        DashboardVC *dashboardVcObj = INSTANTIATE_DASHBOARD(@"DashboardVC");
//        
//      //  [self.navigationController  pushViewController:[ITSApplication getSetSWRevealViewController] animated:YES];
//
//        
//        
//        
//    }else{
//        [GenericMethods alertWithOneBtn:NSLocalizedString(@"Message", @"") andMsg:NSLocalizedString(@"All fields are mandatory", @"") andFirstBtnTitle:NSLocalizedString(@"OK", @"") andViewController:self andCompletionHandler:nil];
//        
//    }
    
    
}

#pragma mark - Authenticate Login Request
-(void)authenticateLogin{
    NSMutableDictionary *parameters =[[NSMutableDictionary alloc] init];
    [parameters setValue:@"testa@etax.com" forKey:@"identifier"];
    [parameters setValue:@"Coffee@111" forKey:@"secret"];
    
    [ITSClient authenticateLogin:parameters withHeaders:[ITSClient headerDictForPSRMApi] completionHandler:^(id result, NSError *error) {
        
        if (error) {
            NSLog(@"error is %@",error.localizedDescription);
        }else{
            NSLog(@"responce is %@",(NSDictionary *)result);
            
            NSDictionary *respDict = (NSDictionary *)result;
            
            NSMutableDictionary *headerDict =[[NSMutableDictionary alloc] init];
            gblAccessToken = [NSString stringWithFormat:@"Bearer %@",[respDict valueForKey:@"accessToken"]];
            [headerDict setValue:[NSString stringWithFormat:@"Bearer %@",[respDict valueForKey:@"accessToken" ]] forKey:@"Authorization"];
            [headerDict setValue:@"application/json" forKey:@"content-type"];
            //[headerDict setValue:@"no-cache" forKey:@"cache-control"];
            [self getProfileReq:headerDict];
            
            DashboardVC *dashboardVcObj = INSTANTIATE_DASHBOARD(@"DashboardVC");
            
            [self.navigationController  pushViewController:[ITSApplication getSetSWRevealViewController] animated:YES];
            
        }
        
        
    }];
}

-(void)getProfileReq :(NSMutableDictionary *)headerDict {
    [ITSClient getProfileReq:headerDict andCompletionHandler:^(id result, NSError *error) {
        
        if (error) {
            DDLogInfo(@" responce is %@",error.localizedDescription);
        }else{
            DDLogInfo(@" responce is %@",(NSDictionary *)result);
            FTAGetProfileModel *ftaGetProfileModel =[[FTAGetProfileModel alloc] initWithDictionary:(NSMutableDictionary *)result];
            gblPsrmID = ftaGetProfileModel.psrmContactId;
        }
        
    }];
    

}
-(void)getAccountsListReq:(NSString *)accId{
    ///test accid = xyz1234
    NSMutableDictionary *headerDict =[[NSMutableDictionary alloc] init];
    [headerDict setValue:gblAccessToken forKey:@"Authorization"];
    [headerDict setValue:@"application/json" forKey:@"content-type"];
    [ITSClient getAccountDetailsReq:headerDict andInpParameter:accId andCompletionHandler:^(id result, NSError *error) {
        if (error) {
            DDLogInfo(@" responce is %@",error.localizedDescription);
        }else{
            DLog(@" responce is %@",(NSDictionary *)result);
        }
    }];

}

@end
