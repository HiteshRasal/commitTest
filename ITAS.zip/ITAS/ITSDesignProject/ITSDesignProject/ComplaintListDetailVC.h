//
//  ComplaintListDetailVC.h
//  ITSDesignProject
//
//  Created by roshan on 16/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ComplaintListDetailVC : ITParentVC <UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>
@property(nonatomic,strong)IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBarForFilter;
@property (strong, nonatomic) NSMutableArray* filteredTableData;
@property (strong,nonatomic) NSString *srTypeVal;
@property (strong,nonatomic) NSString *accId;


@end
