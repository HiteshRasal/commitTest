//
//  Constants.h
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 20/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#ifndef Constants_h
#define Constants_h
#import "ITASApp.h"
static const DDLogLevel ddLogLevel = LOG_LEVEL_VERBOSE;
#ifdef DEBUG
#   define DLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__)
#else
#   define DLog(...)
#endif

// ALog always displays output regardless of the DEBUG setting
#define ALog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__)
#define feedbackUrl @"http://192.168.1.154:8282/SurveySiebel/home/survey"

#define ITSApplication ((ITASApp *)PankanisLiteApplication)

#define RGB(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0]



#pragma mark - PSRM URLS
#define psrmAuthenticationUrl @""
#define psrmGetProfileUrl @""
#define psrmGetAccountsUrl @"http://192.168.2.97:8102/accounts/v1/accounts/"
#define psrmGetAccountDetailsUrl @"http://192.168.2.97:8102/accounts/v1/accounts/"

#pragma mark - Sibel URLS

#endif /* Constants_h */
