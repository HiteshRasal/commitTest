//
//  Defines.h
//  ios_language_manager
//
//  Created by Maxim Bilan on 1/10/15.
//  Copyright (c) 2015 Maxim Bilan. All rights reserved.
//

#define USE_ON_FLY_LOCALIZATION 1
