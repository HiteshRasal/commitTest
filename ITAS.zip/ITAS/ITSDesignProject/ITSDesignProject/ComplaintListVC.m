//
//  ComplaintListVC.m
//  ITSDesignProject
//
//  Created by roshan on 16/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ComplaintListVC.h"
#import "ComplaintListDetailVC.h"
#import "FTASearchVC.h"


@interface ComplaintListVC (){
    NSMutableArray *serviceReqArray;
}

@end

@implementation ComplaintListVC

- (void)viewDidLoad {
    [super viewDidLoad];
  
    self.HomeNavBar.lblTitle.text=@"Service Requests";
    // Do any additional setup after loading the view.
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Search.png"] style:UIBarButtonItemStylePlain target:self action:@selector(callSearchVC)];
    _Tabitems=[[NSMutableArray alloc]initWithObjects:@"COMPLAINT",@"SUGGESTION",@"GENERAL ENQUIRY",@"APPEAL",@"RECONSIDERATION",@"OBJECTION",nil];
    serviceReqArray=[[NSMutableArray alloc] init];
    NSLog(@"TabName is %@",_TabName);
    NSLog(@"_gblAccId is %@",_gblAccId);

    
     ITSApplication.carbonDiscoverTab = [[CarbonTabSwipeNavigation alloc]initWithItems:_Tabitems delegate:self];
    [ITSApplication.carbonDiscoverTab insertIntoRootViewController:self];
    
    UIColor *color = [UIColor blackColor];
    
    ITSApplication.carbonDiscoverTab.toolbar.translucent = NO;
    
    [ITSApplication.carbonDiscoverTab setIndicatorColor:color];
    [ITSApplication.carbonDiscoverTab setTabExtraWidth:15];
    
    [ITSApplication.carbonDiscoverTab setNormalColor:[UIColor lightGrayColor]
                                                font:[UIFont boldSystemFontOfSize:14]];
    [ITSApplication.carbonDiscoverTab setSelectedColor:color font:[UIFont boldSystemFontOfSize:14]];
    
    
    NSLog(@"check the controller %@",ITSApplication.carbonDiscoverTab.viewControllers);
    
    if([_TabName isEqualToString:@"Suggestions"]){
        ITSApplication.carbonDiscoverTab.currentTabIndex = 1;

    }
    else if([_TabName isEqualToString:@"Complaints"]){
        ITSApplication.carbonDiscoverTab.currentTabIndex = 0;

    }else if([_TabName isEqualToString:@"GENERAL ENQUIRY"]){
        ITSApplication.carbonDiscoverTab.currentTabIndex = 2;
        
    }else if([_TabName isEqualToString:@"APPEAL"]){
        ITSApplication.carbonDiscoverTab.currentTabIndex = 3;
        
    }else if([_TabName isEqualToString:@"RECONSIDERATION"]){
        ITSApplication.carbonDiscoverTab.currentTabIndex = 4;
        
    }else if([_TabName isEqualToString:@"OBJECTION"]){
        ITSApplication.carbonDiscoverTab.currentTabIndex = 5;
        
    }
//    else{
//        ITSApplication.carbonDiscoverTab.currentTabIndex = 2;
//    }
   
}
-(void)callSearchVC{
    FTASearchVC *FTASearchVCObj =  INSTANTIATE(@"FTASearchVC");
    [self.navigationController pushViewController:FTASearchVCObj animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - CarbonTabSwipeNavigation Delegate
- (nonnull UIViewController *)carbonTabSwipeNavigation:
(nonnull CarbonTabSwipeNavigation *)carbontTabSwipeNavigation
                                 viewControllerAtIndex:(NSUInteger)index {
    switch (index) {
        case 0:
        {
            NSLog(@"sr type %@",_TabName);
            NSLog(@"_gblAccId is %@",_gblAccId);
            
            
            ComplaintListDetailVC *complaintListDetailVCObj =  INSTANTIATE(@"ComplaintListDetailVC");
            complaintListDetailVCObj.accId = _gblAccId;
            complaintListDetailVCObj.srTypeVal = _TabName;
            return complaintListDetailVCObj;
    }
        case 1:
            return  INSTANTIATE(@"ComplaintListDetailVC");
            
        case 2:
            return INSTANTIATE(@"ComplaintListDetailVC");
            
        default:
            return  INSTANTIATE(@"ComplaintListDetailVC");
    }
}


- (void)carbonTabSwipeNavigation:(nonnull CarbonTabSwipeNavigation *)carbonTabSwipeNavigation
                 willMoveAtIndex:(NSUInteger)index {
    
    
    
}

- (void)carbonTabSwipeNavigation:(nonnull CarbonTabSwipeNavigation *)carbonTabSwipeNavigation
                  didMoveAtIndex:(NSUInteger)index {
    
    
}

#pragma mark - Api request



@end
