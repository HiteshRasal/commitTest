//
//  ComplaintListDetailCell.m
//  ITSDesignProject
//
//  Created by roshan on 16/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ComplaintListDetailCell.h"

@implementation ComplaintListDetailCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
