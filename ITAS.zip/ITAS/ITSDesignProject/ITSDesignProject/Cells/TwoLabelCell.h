//
//  TwoLableCell.h
//  FTA
//
//  Created by Hitesh Rasal on 29/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TwoLabelCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblFirstTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblFirstValue;
@property (strong, nonatomic) IBOutlet UILabel *lblSecondTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblSecondValue;

@end
