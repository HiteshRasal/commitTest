//
//  FormListCell.h
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 17/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FormListCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIView *mainView;
@property (strong, nonatomic) IBOutlet UILabel *lblFormNo;
@property (strong, nonatomic) IBOutlet UILabel *lblStatus;
@property (strong, nonatomic) IBOutlet UILabel *lblCreationDate;
@property (strong, nonatomic) IBOutlet UILabel *lblAccName;
@property (strong, nonatomic) IBOutlet UILabel *lblStaticFormNo;
@property (strong, nonatomic) IBOutlet UILabel *lblStaticStatus;
@property (strong, nonatomic) IBOutlet UILabel *lblStaticCreationDate;
@property (strong, nonatomic) IBOutlet UILabel *lblStaticAccountNo;

@end
