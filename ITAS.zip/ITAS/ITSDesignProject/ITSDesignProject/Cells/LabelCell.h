//
//  LabelCell.h
//  FTA
//
//  Created by Hitesh Rasal on 29/09/17.
//  Copyright © 2017 Pankanis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LabelCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblValue;

@end
