//
//  ComplaintListDetailCell.h
//  ITSDesignProject
//
//  Created by roshan on 16/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ComplaintListDetailCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblSRNO;
@property (weak, nonatomic) IBOutlet UILabel *lblCreatedDate;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

@end
