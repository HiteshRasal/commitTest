//
//  ServiceRequestCell.h
//  ITSDesignProject
//
//  Created by Nagabhushana Rao Vaddi on 16/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServiceRequestCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *dataBaseView;
@property (weak, nonatomic) IBOutlet UILabel *lblServiceRequestNo;
@property (weak, nonatomic) IBOutlet UILabel *lblCreationDate;
@property (weak, nonatomic) IBOutlet UILabel *lblStatus;
@property (weak, nonatomic) IBOutlet UILabel *lblAccountName;

@property (strong, nonatomic) IBOutlet UILabel *lblStaticCompNo;
@property (strong, nonatomic) IBOutlet UILabel *lblStaticStatus;
@property (strong, nonatomic) IBOutlet UILabel *lblStaticCreationDate;
@property (strong, nonatomic) IBOutlet UILabel *lblStaticServReqNo;
@end
