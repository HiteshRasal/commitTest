//
//  RearViewCellTableViewCell.m
//  ITSDesignProject
//
//  Created by roshan on 11/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "RearViewCellTableViewCell.h"

@implementation RearViewCellTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
+ (NSString *)reuseIdentifier
{
    return @"RearViewCell";
}

@end
