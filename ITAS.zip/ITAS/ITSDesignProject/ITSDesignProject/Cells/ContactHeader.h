//
//  ContactHeader.h
//  ITSDesignProject
//
//  Created by roshan on 17/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactHeader : UITableViewHeaderFooterView

@end
