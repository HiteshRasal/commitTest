//
//  ContactHeader.m
//  ITSDesignProject
//
//  Created by roshan on 17/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ContactHeader.h"

@implementation ContactHeader

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
