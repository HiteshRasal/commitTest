//
//  ServiceRequestCell.m
//  ITSDesignProject
//
//  Created by Nagabhushana Rao Vaddi on 16/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ServiceRequestCell.h"

@implementation ServiceRequestCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    self.dataBaseView.layer.borderWidth  = 1;
    self.dataBaseView.layer.cornerRadius = 10;
    self.dataBaseView.layer.borderColor  = [UIColor lightGrayColor].CGColor;
    
}

@end
