//
//  ContactCell.m
//  ITSDesignProject
//
//  Created by roshan on 17/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import "ContactCell.h"

@implementation ContactCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)locationButtonTapped:(id)sender {
    _handler(self);
    
}

@end
