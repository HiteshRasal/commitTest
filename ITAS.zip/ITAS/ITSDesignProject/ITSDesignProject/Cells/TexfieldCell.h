//
//  TexfieldCell.h
//  Mirror
//
//  Created by Hitesh Rasal on 31/01/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TexfieldCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextField *txtCustomField;
@property (weak, nonatomic) IBOutlet UILabel *lblName;

@end
