//
//  RearViewCellTableViewCell.h
//  ITSDesignProject
//
//  Created by roshan on 11/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RearViewCellTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *CellTitle;
@property (weak, nonatomic) IBOutlet UIImageView *IconImage;
+(NSString *)reuseIdentifier;

@end
