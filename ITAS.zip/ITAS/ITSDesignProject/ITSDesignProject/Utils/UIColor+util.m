//
//  UIColor+util.m
//  DemoSwipeViews
//
//  Created by Jags on 19/08/17.
//  Copyright © 2017 pankanis. All rights reserved.
//
#define THEME_COLOR_HEX  @"125EA3"
#define LABEL_HEADING_COLOR_HEX  @"125EA3"
#define LABEL_DESC_COLOR_HEX  @"125EA3"
#define THEME_COLOR_HEX  @"125EA3"
#define THEME_COLOR_HEX  @"125EA3"

#import "UIColor+util.h"

@implementation UIColor (util)
// Create a color using a string with a webcolor
// ex. [UIColor colorWithHexString:@"#03047F"]
+ (UIColor *) colorWithHexString:(NSString *)hexstr {
    NSScanner *scanner;
    unsigned int rgbval;
    
    scanner = [NSScanner scannerWithString: hexstr];
    [scanner setCharactersToBeSkipped:[NSCharacterSet characterSetWithCharactersInString:@"#"]];
    [scanner scanHexInt: &rgbval];
    
    return [UIColor colorWithHex: rgbval];
}

+ (UIColor *)colorWithHex:(NSInteger)hex
{
    return [UIColor colorWithRed:((CGFloat)((hex & 0xFF0000) >> 16)) / 255.0f
                           green:((CGFloat)((hex & 0x00FF00) >> 8)) / 255.0f
                            blue:((CGFloat)((hex & 0x0000FF) >> 0)) / 255.0f
                           alpha:1.0];
}

+ (UIColor *)themeColor
{
    return [UIColor colorWithHexString:@"#343C47"];
}

+ (UIColor *)headingLabelColor
{
    return [UIColor colorWithHexString:@"#afafaf"];
}

+ (UIColor *)descriptionLabelColor
{
    return [UIColor colorWithHexString:@"#494949"];
}


+ (UIColor *)textFieldColor
{
    return [UIColor colorWithHexString:@"125EA3"];
}

+ (UIColor *)textFieldUnderLineColor
{
    return [UIColor colorWithHexString:@"125EA3"];
}
+ (UIColor *)disableThemeColor
{
    return [UIColor lightGrayColor];
}


@end
