//
//  UIColor+util.h
//  DemoSwipeViews
//
//  Created by Jags on 19/08/17.
//  Copyright © 2017 pankanis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (util)
+ (UIColor *) colorWithHexString:(NSString *)hex;
+ (UIColor *)colorWithHex:(NSInteger)hex;
+ (UIColor *)descriptionLabelColor;
+ (UIColor *)headingLabelColor;
+ (UIColor *)textFieldColor;
+ (UIColor *)textFieldUnderLineColor;
+ (UIColor *)themeColor;
+ (UIColor *)disableThemeColor;
@end
