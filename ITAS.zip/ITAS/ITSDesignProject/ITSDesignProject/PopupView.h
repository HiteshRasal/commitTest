//
//  MessageView.h
//  Tyunami
//
//  Created by Jagprit Batra on 28/07/17.
//  Copyright © 2017 Nagabhushan. All rights reserved.
//

#import <UIKit/UIKit.h>

// KLCPopupMaskType
typedef NS_ENUM(NSInteger, BUTTON_TYPE) {
    BUTTON_OTHER = 0,
    BUTTON_CANCEL,
    BUTTON_ACTION,
};

@interface PopupView : UIView{
    UIView * view;
    
}
@property (weak, nonatomic) IBOutlet UIStackView *stackView;
@property (weak, nonatomic) IBOutlet UILabel *lblMessage;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *messageHeightLayout;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *titleHeightLayout;
+ (id)loadInstanceFromNibWithData:(id)data;
@property (nonatomic, copy) void (^buttonClicked)(BUTTON_TYPE);
@end
