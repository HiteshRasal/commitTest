//
//  MessageView.m
//  Tyunami
//
//  Created by Jagprit Batra on 28/07/17.
//  Copyright © 2017 Nagabhushan. All rights reserved.
//

#import "PopupView.h"

@implementation PopupView

+ (id)loadInstanceFromNibWithData:(id)data
{
    UIView *result = [[[NSBundle mainBundle] loadNibNamed:@"PopupView" owner:self options:nil] objectAtIndex:0];
    result.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleHeight;
    [result setTranslatesAutoresizingMaskIntoConstraints:NO];
    [result layoutIfNeeded];
    [result invalidateIntrinsicContentSize];
    return result;
    
}
- (void)layoutSubviews {
    [super layoutSubviews];
    self.lblMessage.text = @"";
    [self.lblMessage sizeToFit];
}

- (CGSize)intrinsicContentSize {
    CGFloat height = 0.0;
    
    self.messageHeightLayout.constant = 0.0;

    height += self.lblTitle.bounds.size.height;
    height += self.lblMessage.bounds.size.height;
    height += self.stackView.bounds.size.height;
    CGSize size = CGSizeMake([UIScreen mainScreen].bounds.size.width - 20, height);
    return size;
}
- (IBAction)buttonClicked:(id)sender {
    UIButton * btn = (UIButton*)sender;
    if(self.buttonClicked){
        self.buttonClicked(btn.tag);
    }
}

/*
- (id)initWithFrame:(CGRect)aRect
{
    if ((self = [super initWithFrame:aRect])) {
      //  [self xibSetup];
    }
    return self;
}

- (id)initWithCoder:(NSCoder*)coder
{
    if ((self = [super initWithCoder:coder])) {
      //  [self xibSetup];
    }
    return self;
}



-(void)xibSetup{
    view = [self loadViewFromNib];
    view.frame = self.bounds;
    view.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleHeight;
    [self addSubview:view];
}

-(UIView*)loadViewFromNib{
    return  [[[NSBundle mainBundle] loadNibNamed:@"MediaPlayerMessageView" owner:self options:nil] objectAtIndex:0];
}
*/



@end
