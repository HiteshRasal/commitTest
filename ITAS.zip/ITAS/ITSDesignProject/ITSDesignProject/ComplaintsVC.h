//
//  ComplaintsVC.h
//  ITSDesignProject
//
//  Created by roshan on 16/08/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ITParentVC.h"

@interface ComplaintsVC : ITParentVC<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) NSMutableArray* tableArray;
@property(strong,nonatomic)NSString * TabName;
@end
