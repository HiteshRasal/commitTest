//
//  LoginVc.h
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 14/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

extern NSString *gblPsrmID;
extern NSString *gblAccessToken;

#import <UIKit/UIKit.h>



@interface LoginVc : UIViewController<UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UIButton *btnSignIn;
- (IBAction)SignInAction:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *lblEmail;
@property (strong, nonatomic) IBOutlet UILabel *lblPassword;
@property (strong, nonatomic) IBOutlet UITextField *txtEmail;
@property (strong, nonatomic) IBOutlet UITextField *txtPassWord;

@end
