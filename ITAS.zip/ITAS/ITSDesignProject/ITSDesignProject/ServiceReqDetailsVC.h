//
//  ServiceReqDetailsVC.h
//  ITSDesignProject
//
//  Created by Hitesh Rasal on 17/07/17.
//  Copyright © 2017 Hitesh Rasal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServiceReqDetailsVC : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *lblAccNo;
@property (strong, nonatomic) IBOutlet UILabel *lblSerReqNo;
@property (strong, nonatomic) IBOutlet UILabel *lblStatus;
@property (strong, nonatomic) IBOutlet UILabel *lblDate;
@property (strong,nonatomic) NSString *accName;
@property (strong,nonatomic) NSString *serReqNo;
@property (strong,nonatomic) NSString *status;
@property (strong,nonatomic) NSString *creationDate;

@property (strong, nonatomic) IBOutlet UILabel *lblStaticName;
@property (strong, nonatomic) IBOutlet UILabel *lblStaticNo;
@property (strong, nonatomic) IBOutlet UILabel *lblStaticStatus;
@property (strong, nonatomic) IBOutlet UILabel *lblStaticCreationDate;

@end
